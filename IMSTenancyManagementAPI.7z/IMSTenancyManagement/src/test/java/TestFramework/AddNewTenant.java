package TestFramework;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import java.util.List;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import resources.BaseExtentReport;
import resources.NewExcelConfig;
import ObjRepo.ObjInfo;

public class AddNewTenant extends BaseExtentReport{
	
	NewExcelConfig nec = new NewExcelConfig();
	ObjInfo oInfo=new ObjInfo();
	@Test(priority=1)
			public void AddTenant() throws Exception
			{
					
					
					test=report.createTest("TC# 1 :: AddTenant");
					
					nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
					String Name = nec.GetData(2, 4, 5);
					RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net";
					
					Response res = given().
							header("Content-Type","application/json").
							body( "{\"companyName\":\""+Name+"\",\"companyNumber\":\"1236547899\",\"description\":\"techwave is a level3 company\","
									+ "\"addressLine1\":\"hyd2\",\"addressLine2\":\"hyd2\",\"addressLine3\":\"hyd3\",\"city\":\"Hyderabad\","
									+ "\"stateProvince\":\"Hyderabad\",\"postalCode\":\"516999\",\"countryName\":\"United Kingdom\","
									+ "\"timeZoneName\":\"(UTC) Coordinated Universal Time\",\"primaryPhone\":\"1234567890\","
									+ "\"primaryEmail\":\"techwave@gmail.com\",\"StatusTypeName\":\"New\"}").
							when().
							post(nec.GetData(2, 4, 4)).
							then().extract().response();
					int statusCode = res.getStatusCode();
					System.out.println(statusCode);
					
						
					String s =String.valueOf(statusCode);
					nec.setCellData(2,4, 8, s);
					if(s.equals(nec.GetData(2, 4, 7)))
					{
						System.out.println("pass");
						nec.setCellData(2, 4, 9, "pass");
						String responseString=res.asString();
						JsonPath js= new JsonPath(responseString);
						String RegistryID=js.get("data.tenantId");
						System.out.println(RegistryID);
						nec.setCellData(2, 4, 10, RegistryID);
					}
					else{
						System.out.println("fail");
						nec.setCellData(2, 4, 9, "fail");
						String responseString=res.asString();
						JsonPath js= new JsonPath(responseString);
						String errmsg=js.get("error.message");
						nec.setCellData(2, 4, 10, errmsg);
					}
					
			}
	@Test(priority=2)
			public void Nullvalue() throws Exception
			{
		test=report.createTest("TC# 2 :: Nullvalue");
		
		nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
		String Name = nec.GetData(2, 5, 5);
		RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net";
		
		Response res = given().
				header("Content-Type","application/json").
				body( "{\"companyName\":"+Name+",\"companyNumber\":\"1236547899\",\"description\":\"techwave is a level3 company\","
						+ "\"addressLine1\":\"hyd2\",\"addressLine2\":\"hyd2\",\"addressLine3\":\"hyd3\",\"city\":\"Hyderabad\","
						+ "\"stateProvince\":\"Hyderabad\",\"postalCode\":\"516999\",\"countryName\":\"United Kingdom\","
						+ "\"timeZoneName\":\"(UTC) Coordinated Universal Time\",\"primaryPhone\":\"1234567890\","
						+ "\"primaryEmail\":\"techwave@gmail.com\",\"StatusTypeName\":\"New\"}").
				when().
				post(nec.GetData(2, 5, 4)).
				then().assertThat().extract().response();
		int statusCode = res.getStatusCode();
		System.out.println(statusCode);
		
		String s =String.valueOf(statusCode);
		
		String responseString=res.asString();
		JsonPath js= new JsonPath(responseString);
		String errmsg=js.get("errors.Name[0]");
		nec.setCellData(2, 5, 10, errmsg);
		
		nec.setCellData(2,5, 8, s);
		if(s.equals(nec.GetData(2, 5, 7)))
		{
			System.out.println("pass");
			nec.setCellData(2, 5, 9, "pass");
		}
		else{
			System.out.println("fail");
			nec.setCellData(2, 5, 9, "fail");
		}
			}
	@Test(priority=3)
		public void AddTenantInvalidMethod() throws Exception
		{
				
				test=report.createTest("TC# 3 :: AddTenantInvalidMethod");
				
				nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
				String Name = nec.GetData(2, 6, 5);
				RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net";
				
				Response res = given().
						header("Content-Type","application/json").
						body( "{\"companyName\":"+Name+",\"companyNumber\":\"1236547899\",\"description\":\"techwave is a level3 company\","
								+ "\"addressLine1\":\"hyd2\",\"addressLine2\":\"hyd2\",\"addressLine3\":\"hyd3\",\"city\":\"Hyderabad\","
								+ "\"stateProvince\":\"Hyderabad\",\"postalCode\":\"516999\",\"countryName\":\"United Kingdom\","
								+ "\"timeZoneName\":\"(UTC) Coordinated Universal Time\",\"primaryPhone\":\"1234567890\","
								+ "\"primaryEmail\":\"techwave@gmail.com\",\"StatusTypeName\":\"New\"}").
						when().
						put(nec.GetData(2, 6, 4)).
						then().extract().response();
				int statusCode = res.getStatusCode();
				System.out.println(statusCode);
				
					
				String s =String.valueOf(statusCode);
				nec.setCellData(2,6, 8, s);
				if(s.equals(nec.GetData(2, 6, 7)))
				{
					System.out.println("pass");
					nec.setCellData(2, 6, 9, "pass");
				}
				else{
					System.out.println("fail");
					nec.setCellData(2, 6, 9, "fail");
					
				}
				
		}
	@Test(priority=4)
		public void APITenantID() throws Exception
		{
				
				test=report.createTest("TC# 4 :: APITenantID");
				
				nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
				
				RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net/api/tenant";
				
				Response res = given().
						header("Content-Type","application/json").
						when().
						get(nec.GetData(2, 4, 10)).
						then().extract().response();
				int statusCode = res.getStatusCode();
				System.out.println(statusCode);
					
				String s =String.valueOf(statusCode);
				nec.setCellData(2,7, 8, s);
				if(s.equals(nec.GetData(2, 7, 7)))
				{
					System.out.println("pass");
					nec.setCellData(2, 7, 9, "pass");
				}
				else{
					System.out.println("fail");
					nec.setCellData(2, 7, 9, "fail");
					
				}
				
		}
	
		
	
}
	

