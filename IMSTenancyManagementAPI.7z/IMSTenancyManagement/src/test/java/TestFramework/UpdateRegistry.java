package TestFramework;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import ObjRepo.ObjInfo;
import resources.BaseExtentReport;
import resources.NewExcelConfig;

public class UpdateRegistry extends BaseExtentReport{
	
	NewExcelConfig nec = new NewExcelConfig();
	ObjInfo oInfo=new ObjInfo();
	
	@Test(priority=1)
	public void UpdateRegister() throws Exception
	{
			
			test=report.createTest("TC# 5 :: UpdateRegister");
			
			nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
			String Name = nec.GetData(1, 8, 5);
			RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net/api/ApiRegistry";
			
			Response res = given().
					header("Content-Type","application/json").
					body( "{\"name\":\""+Name+"\",\"description\":\"Test Api\",\"version\":\"1.0\","
					        + "\"isDefault\":true,\"isDeleted\":false}").
					when().
					put(nec.GetData(1, 4, 10)).
					then().extract().response();
			int statusCode = res.getStatusCode();
			System.out.println(statusCode);
			
			String s =String.valueOf(statusCode);
			nec.setCellData(1,8, 8, s);
			if(s.equals(nec.GetData(1, 8, 7)))
			{
				String responseString=res.asString();
				JsonPath js= new JsonPath(responseString);
				String UpdateResponse=js.get("data.apiRegistryId");
				System.out.println(UpdateResponse);
				//System.out.println("pass");
				nec.setCellData(1, 8, 10, UpdateResponse);
				nec.setCellData(1, 8, 9, "pass");
			}
			else{
				System.out.println("fail");
				nec.setCellData(1, 8, 9, "fail");
				String responseString=res.asString();
				JsonPath js= new JsonPath(responseString);
				String Response=js.get("error.message");
				System.out.println(Response	);
				nec.setCellData(1, 8, 10, Response);
				
			}
			
	}

	@Test(priority=2)
	public void UpdateRegisterInvalidMethod() throws Exception
	{
			
			test=report.createTest("TC# 2 :: UpdateRegisterInvalidMethod");
			
			nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
			String Name = nec.GetData(1, 9, 5);
			RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net/api/tenant";
			
			Response res = given().
					header("Content-Type","application/json").
					body( "{\"name\":\""+Name+"\",\"description\":\"Test Api\",\"version\":\"1.0\","
					        + "\"isDefault\":true,\"isDeleted\":false}").
					when().
					put(nec.GetData(1, 9, 10)).
					then().extract().response();
			int statusCode = res.getStatusCode();
			System.out.println(statusCode);
			
			String s =String.valueOf(statusCode);
			nec.setCellData(1,9, 8, s);
			if(s.equals(nec.GetData(1, 9, 7)))
			{
				
				nec.setCellData(1, 9, 9, "pass");
			}
			else{
				System.out.println("fail");
				nec.setCellData(1, 9, 10, "fail");
				
			}
			
	}

}
