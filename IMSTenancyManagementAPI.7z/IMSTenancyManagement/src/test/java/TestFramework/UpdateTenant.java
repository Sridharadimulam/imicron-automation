package TestFramework;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import ObjRepo.ObjInfo;
import resources.BaseExtentReport;
import resources.NewExcelConfig;

public class UpdateTenant extends BaseExtentReport{
	
	NewExcelConfig nec = new NewExcelConfig();
	ObjInfo oInfo=new ObjInfo();
	
	@Test(priority=1)
	public void UpdateTenants() throws Exception
	{
			
			test=report.createTest("TC# 1 :: UpdateTenants");
			
			nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
			String Name = nec.GetData(2, 8, 5);
			RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net/api/tenant";
			
			Response res = given().
					header("Content-Type","application/json").
					body( "{\"companyName\":\""+Name+"\",\"companyNumber\":\"1236547899\",\"description\":\"techwave is a level3 company\","
							+ "\"addressLine1\":\"hyd2\",\"addressLine2\":\"hyd2\",\"addressLine3\":\"hyd3\",\"city\":\"Hyderabad\","
							+ "\"stateProvince\":\"Hyderabad\",\"postalCode\":\"516999\",\"countryName\":\"United Kingdom\","
							+ "\"timeZoneName\":\"(UTC) Coordinated Universal Time\",\"primaryPhone\":\"1234567890\","
							+ "\"primaryEmail\":\"techwave@gmail.com\",\"StatusTypeName\":\"New\"}").
					when().
					put(nec.GetData(2, 4, 10)).
					then().extract().response();
			int statusCode = res.getStatusCode();
			System.out.println(statusCode);
			
			String s =String.valueOf(statusCode);
			nec.setCellData(2,8, 8, s);
			if(s.equals(nec.GetData(2, 8, 7)))
			{
				String responseString=res.asString();
				JsonPath js= new JsonPath(responseString);
				String UpdateResponse=js.get("data.tenantId");
				System.out.println(UpdateResponse);
				//System.out.println("pass");
				nec.setCellData(2, 8, 10, UpdateResponse);
				nec.setCellData(2, 8, 9, "pass");
			}
			else{
				System.out.println("fail");
				nec.setCellData(2, 8, 9, "fail");
				String responseString=res.asString();
				JsonPath js= new JsonPath(responseString);
				String Response=js.get("error.message");
				System.out.println(Response	);
				nec.setCellData(2, 8, 10, Response);
				
			}
			
	}
@Test(priority=2)
	public void UpdateTenantsInvalidMethod() throws Exception
	{
			
			test=report.createTest("TC# 2 :: UpdateTenantsInvalidMethod");
			
			nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
			String Name = nec.GetData(2, 9, 5);
			RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net/api/tenant";
			
			Response res = given().
					header("Content-Type","application/json").
					body( "{\"companyName\":\""+Name+"\",\"companyNumber\":\"1236547899\",\"description\":\"techwave is a level3 company\","
							+ "\"addressLine1\":\"hyd2\",\"addressLine2\":\"hyd2\",\"addressLine3\":\"hyd3\",\"city\":\"Hyderabad\","
							+ "\"stateProvince\":\"Hyderabad\",\"postalCode\":\"516999\",\"countryName\":\"United Kingdom\","
							+ "\"timeZoneName\":\"(UTC) Coordinated Universal Time\",\"primaryPhone\":\"1234567890\","
							+ "\"primaryEmail\":\"techwave@gmail.com\",\"StatusTypeName\":\"New\"}").
					when().
					put(nec.GetData(2, 9, 10)).
					then().extract().response();
			int statusCode = res.getStatusCode();
			System.out.println(statusCode);
			
			String s =String.valueOf(statusCode);
			nec.setCellData(2,9, 8, s);
			if(s.equals(nec.GetData(2, 9, 7)))
			{
				
				nec.setCellData(2, 9, 9, "pass");
			}
			else{
				System.out.println("fail");
				nec.setCellData(2, 9, 10, "fail");
				
			}
			
	}


}
