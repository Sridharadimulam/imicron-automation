package TestFramework;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;
import org.testng.annotations.Test;

import ObjRepo.ObjInfo;
import resources.BaseExtentReport;
import resources.NewExcelConfig;

public class GetRegistries extends BaseExtentReport{
	
	NewExcelConfig nec = new NewExcelConfig();
	ObjInfo oInfo=new ObjInfo();
	
	@Test(priority=1)
public void GetAllRegistries () throws Exception
{
		
		test=report.createTest("TC# 1 :: GetAllRegistries");
		
		nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
		RestAssured.baseURI=oInfo.BaseURL;
		
		Response Res =given().
		       when().
		       get(nec.GetData(1, 1, 4)).
		       then().extract().response();
		      
		int statusCode = Res.getStatusCode();
		System.out.println(statusCode);
		String s =String.valueOf(statusCode);
		
		if(s.equals(nec.GetData(1, 1, 7)))
		{
			System.out.println("pass");
			nec.setCellData(1, 1, 9, "pass");
		}
		else{
			System.out.println("fail");
			nec.setCellData(1, 1, 9, "fail");
		}
		
		nec.setCellData(1, 1, 8, s);
		//nec.setCellData(1,1,5, "pass");
		
}
	@Test(priority=2)
	public void InvalidURL() throws Exception
	{
        test=report.createTest("TC# 2 :: InvalidURL");
        nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net";
		
		Response Res1 =given().
		       when().
		       get(nec.GetData(1, 2, 4)).
		       then().extract().response();
		
		int statusCode = Res1.getStatusCode();
		System.out.println(statusCode);
		//Assert.assertEquals(statusCode, 404 , "Correct status code returned");
		String s =String.valueOf(statusCode);
		
		if(s.equals(nec.GetData(1, 2, 7)))
		{
			System.out.println("pass");
			nec.setCellData(1, 2, 9, "pass");
		}
		else{
			System.out.println("fail");
			nec.setCellData(1, 2, 9, "fail");
		}
		
		nec.setCellData(1, 2, 8, s);
		//nec.setCellData(1,1,5, "pass");
	}
	@Test(priority=3)
	public void InvalidMethod () throws Exception
	{
			
			test=report.createTest("TC# 3 :: InvalidMethod");
			
			nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
			RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net";
			
			Response Res =given().
			       when().
			       patch(nec.GetData(1, 3, 4)).
			       then().extract().response();
			      
			int statusCode = Res.getStatusCode();
			
			System.out.println(statusCode);
			String s =String.valueOf(statusCode);
			if(s.equals(nec.GetData(1, 3, 7)))
			{
				System.out.println("pass");
				nec.setCellData(1, 3, 9, "pass");
			}
			else{
				System.out.println("fail");
				nec.setCellData(1, 3, 9, "fail");
			}
			
			
			
			nec.setCellData(1, 3, 8, s);
			//nec.setCellData(1,1,5, "pass");
			
	}
		
	}

