package TestFramework;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import resources.BaseExtentReport;
import resources.NewExcelConfig;
import ObjRepo.ObjInfo;

public class DeleteTenant extends BaseExtentReport{
	
	NewExcelConfig nec = new NewExcelConfig();
	ObjInfo oInfo=new ObjInfo();
	
	@Test(priority=1)
	public void DeleteTenantID() throws Exception
	{
			
			test=report.createTest("TC# 1 :: DeleteTenantID");
			
			nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
			
			RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net/api/tenant";
			
			Response res = given().
					header("Content-Type","application/json").
					when().
					delete(nec.GetData(2, 4, 10)).
					then().extract().response();
			int statusCode = res.getStatusCode();
			System.out.println(statusCode);
			
			
				
			String s =String.valueOf(statusCode);
			nec.setCellData(2,10, 8, s);
			if(s.equals(nec.GetData(2, 10, 7)))
			{
				String responseString=res.asString();
				JsonPath js= new JsonPath(responseString);
				String DeleteResponse=js.get("data");
				System.out.println(DeleteResponse);
				System.out.println("pass");
				nec.setCellData(2, 10, 9, "pass");
				nec.setCellData(2, 10, 10, DeleteResponse);
			}
			else{
				System.out.println("fail");
				nec.setCellData(2, 10, 9, "fail");
				String responseString=res.asString();
				JsonPath js= new JsonPath(responseString);
				String errmsg=js.get("error.message");			
				nec.setCellData(2, 10, 10, errmsg);
			}
			
	}
	@Test(priority=2)
	public void InvalidMethodDeleteTenantID() throws Exception
	{
			
			test=report.createTest("TC# 2 :: InvalidMethodDeleteTenantID");
			
			nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
			
			RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net/api/tenant";
			
			Response res = given().
					header("Content-Type","application/json").
					when().
					post(nec.GetData(2, 4, 10)).
					then().extract().response();
			int statusCode = res.getStatusCode();
			System.out.println(statusCode);
			
			
				
			String s =String.valueOf(statusCode);
			nec.setCellData(2,11, 8, s);
			if(s.equals(nec.GetData(2, 11, 7)))
			{
				
				System.out.println("pass");
				nec.setCellData(2, 11, 9, "pass");
				
			}
			else{
				System.out.println("fail");
				nec.setCellData(2, 11, 9, "fail");
			}
			
	}


}
