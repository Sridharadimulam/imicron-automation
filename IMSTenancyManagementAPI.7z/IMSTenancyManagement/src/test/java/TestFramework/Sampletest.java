package TestFramework;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Sampletest {
	
	WebDriver obrw;
	@Test
	public void openbrowser()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\10504\\workspace\\IMSTenancyManagement\\src\\main\\java\\Driver\\chromedriver.exe");
		obrw=new ChromeDriver();
		obrw.manage().window().maximize();
		obrw.get("https://www.google.co.in");
	}

}
