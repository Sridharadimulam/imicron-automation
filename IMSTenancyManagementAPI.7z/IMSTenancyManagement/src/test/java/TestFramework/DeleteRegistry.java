package TestFramework;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import resources.BaseExtentReport;
import resources.NewExcelConfig;
import ObjRepo.ObjInfo;

public class DeleteRegistry extends BaseExtentReport{
	
	NewExcelConfig nec = new NewExcelConfig();
	ObjInfo oInfo=new ObjInfo();
	
	@Test(priority=1)
	public void DeleteregistryID() throws Exception
	{
			
			test=report.createTest("TC# 1 :: DeleteregistryID");
			
			nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
			
			RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net/api/ApiRegistry";
			
			Response res = given().
					header("Content-Type","application/json").
					when().
					delete(nec.GetData(1, 4, 10)).
					then().extract().response();
			int statusCode = res.getStatusCode();
			System.out.println(statusCode);
			
			
				
			String s =String.valueOf(statusCode);
			nec.setCellData(1,10, 8, s);
			if(s.equals(nec.GetData(1, 10, 7)))
			{
				String responseString=res.asString();
				JsonPath js= new JsonPath(responseString);
				String DeleteResponse=js.get("data");
				System.out.println(DeleteResponse);
				System.out.println("pass");
				nec.setCellData(1, 10, 9, "pass");
				nec.setCellData(1, 10, 10, DeleteResponse);
			}
			else{
				System.out.println("fail");
				nec.setCellData(1, 10, 9, "fail");
				String responseString=res.asString();
				JsonPath js= new JsonPath(responseString);
				String Response=js.get("error.message");
				nec.setCellData(1, 10, 10, Response);
				
			}
			
	}


}
