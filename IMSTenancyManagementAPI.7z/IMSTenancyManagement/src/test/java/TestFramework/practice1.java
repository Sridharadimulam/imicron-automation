package TestFramework;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

















import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import okhttp3.ResponseBody;

import org.apache.logging.log4j.*;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import resources.BaseExtentReport;
import resources.NewExcelConfig;
import resources.dataDriven;
import ObjRepo.ObjInfo;
import Reusablemethods.payLoad;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.internal.assertion.Assertion;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class practice1 extends BaseExtentReport{

	NewExcelConfig nec = new NewExcelConfig();
	ObjInfo oInfo=new ObjInfo();
	@Test
	public void invalidurl() throws Exception

	{
		nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
		String Name = nec.GetData(1, 3, 5);
		RestAssured.baseURI="https://tenantmanagerapiqa.azurewebsites.net";
		Response res = given().
				
		header("Content-Type","application/json").
		when().
		patch("/api/ApiRegistry").
		then().assertThat().statusCode(405).and().
		extract().response();
		
		int statusCode = res.getStatusCode();
		System.out.println(statusCode);
		Assert.assertEquals(statusCode /*actual value*/, 405 /*expected value*/, "Correct status code returned");
		
		Assert.assertEquals(statusCode, 405 , "Correct status code returned");
	     }
}
        
        
	    
		
		    
	
			
			

		
	 		
				
				
				
		

	


