package TestFramework;

import java.io.IOException;

import org.testng.annotations.Test;

import ObjRepo.ObjInfo;
import resources.NewExcelConfig;

public class Masterclass
{
	
	NewExcelConfig nec = new NewExcelConfig();
    ObjInfo oInfo=new ObjInfo();
    GetRegistries GR = new GetRegistries();
    AddRegistry AR = new AddRegistry();        
    
    
            @Test(priority=1)
            public void GetRegDriver() throws Exception, Exception
            {
                        //S4FinGLParallelLedgerTest GLPLT=new S4FinGLParallelLedgerTest();
                        //ExcelRead oExcel=new ExcelRead("D:\\projects\\GST\\GSTFramework-18072017\\src\\test\\java\\testData\\TestDataEE.xls","TestSuite");
                        
                       // oExcelcon.readExcel("C:\\Users\\10840\\Desktop\\Projects\\S4HanaLifeSciences\\src\\test\\java\\testData", "TestDataLifeSciences.xlsx", "TestSuite");
                        //nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[0]);
            	nec.readExcel("C:\\Users\\10504\\workspace\\IMSTenancyManagement\\src\\main\\java\\TestData", "IMSTenancyAPITestData.xlsx", "Testscipts");
                        int NoOfScenarios=nec.rowCount(0);
                        System.out.println(NoOfScenarios);
                        String sScenario,sExecutionFlag,sAction;
                        int iActCnt;
                        for(int i=1;i<=NoOfScenarios;i++)
                        {
                                    sScenario=nec.GetData(0,i,0);
                                    sExecutionFlag=nec.GetData(0,i,1);
                                    if(sExecutionFlag.equalsIgnoreCase("Yes"))
                                    {
                                                iActCnt=2;
                                                while(nec.GetData(0,i,iActCnt)!="")
                                                {
                                                            sAction=nec.GetData(0,i,iActCnt);
                                                            System.out.println(sAction);
                                                            if(sAction.equals("GetAllRegistries"))
                                                                        GR.GetAllRegistries();
                                                            else if(sAction.equals("InvalidURL"))
                                                                        GR.InvalidURL();
                                                            else if(sAction.equals("InvalidMethod"))
                                                                GR.InvalidMethod();
                                                            
                                                           iActCnt++;
                                                }
                                    }
                                    else
                                                System.out.println(sScenario + " is Skipped");
                        } }
            
            
            
}
