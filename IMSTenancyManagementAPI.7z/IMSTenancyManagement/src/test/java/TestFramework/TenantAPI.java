package TestFramework;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import resources.BaseExtentReport;
import resources.NewExcelConfig;
import ObjRepo.ObjInfo;

public class TenantAPI extends BaseExtentReport{
	
	NewExcelConfig nec = new NewExcelConfig();
	ObjInfo oInfo=new ObjInfo();
	
	@Test(priority=1)
public void GetAllRegistries () throws Exception
{
		
		test=report.createTest("TC# 1 :: GetAllRegistries");
		
		nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
		RestAssured.baseURI=oInfo.BaseURL;
		
		Response Res =given().
		       when().
		       get(nec.GetData(1, 1, 4)).
		       then().extract().response();
		      
		int statusCode = Res.getStatusCode();
		System.out.println(statusCode);
		String s =String.valueOf(statusCode);
		
		if(s.equals(nec.GetData(1, 1, 7)))
		{
			System.out.println("pass");
			nec.setCellData(1, 1, 9, "pass");
		}
		else{
			System.out.println("fail");
			nec.setCellData(1, 1, 9, "fail");
		}
		
		nec.setCellData(1, 1, 8, s);
		//nec.setCellData(1,1,5, "pass");
		
}

}
