package Reusablemethods;

import resources.NewExcelConfig;
import ObjRepo.ObjInfo;

public class payLoad {
	static NewExcelConfig nec = new NewExcelConfig();
		static ObjInfo oInfo=new ObjInfo();
		//You can call method from the class name with className.method if that method is defined with static
		public static String PostRegBody()
		{
		
			String Name = nec.GetData(1, 4, 5);
			String RegBody ="{\"name\":\""+Name+"\",\"description\":\"Test Api\",\"version\":\"1.0\","
			        + "\"isDefault\":true,\"isDeleted\":false}";
			
			
			return RegBody;
		}
		public static String PostNullRegBody()
		{
		String Name = nec.GetData(1, 5, 5);
		String NullRegBody ="{\"name\":\""+Name+"\",\"description\":\"Test Api\",\"version\":\"1.0\","
		        + "\"isDefault\":true,\"isDeleted\":false}";
		
		
		return NullRegBody;

	}

}