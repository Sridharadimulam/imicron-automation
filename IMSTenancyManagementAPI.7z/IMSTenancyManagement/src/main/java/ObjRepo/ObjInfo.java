package ObjRepo;

public class ObjInfo {	
	

	public String ExcelPath=System.getProperty("user.dir") +"/src/main/java/TestData";			
	public String ExcelFile="IMSTenancyAPITestData.xlsx";
	public String DriverPath=System.getProperty("user.dir") +"/src/main/java/Driver/chromedriver.exe";
	public String HostPath=System.getProperty("user.dir")+"/env.properties";
	public String XMLPath =System.getProperty("user.dir") +"/src/main/java/resources/Tenancy.xml";
	public String HtmlPath=System.getProperty("user.dir") +"/test-output/IMSTenancyReport.html";				
	public String[] SheetName = new String[]{"TestScripts","Registry"};
	
	
	public String BaseURL = "https://tenantmanagerapiqa.azurewebsites.net";
}

