package com.bikroy.framework.globals;

import com.bikroy.framework.interfaces.IBrowser;

public class GlobalController {
	public static IBrowser brw = null;
}
