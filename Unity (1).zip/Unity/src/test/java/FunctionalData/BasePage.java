package FunctionalData;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import FunctionalData.BaseExtentReport;

import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;

public class BasePage  {
	

	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular waitall =new waitforangular();
functionLibs fun = new functionLibs();




//readExcelData oExcelcon = new readExcelData();


String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
String FileName="UnityTestData.xlsx";
String SheetName="UsersPage";



@Test(priority=1)
public void chromedr() throws Exception 
{
	
	//test=report.createTest("TC# 1 :: CreateUser"); 
	
	System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
	obrw=new ChromeDriver();
	
	obrw.manage().window().maximize();
	obrw.get("http://www.imicrondev.com/QA/Enterprise/Portal");
	return ;
}
}