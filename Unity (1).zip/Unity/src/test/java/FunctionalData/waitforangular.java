package FunctionalData;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.TestException;

import com.paulhammant.ngwebdriver.NgWebDriver;

public class waitforangular {
	   public static NgWebDriver ngwebdriver;
	 
	protected static final String DOCUMENT_READY = "return document.readyState == 'complete';"; 

	public void waitforPageLoad(WebDriver driver) throws TestException {
		boolean documentReady;
		int attempts = 1;
	    int waitTime=100;
	    JavascriptExecutor executor = (JavascriptExecutor) driver;
		  //waitforJQueryToLoad();
		do {
			documentReady = ((String) executor.executeScript("return document.readyState")).equals("complete");
			
			//Object //logger;
			if (documentReady) {
				//logger.info(pageName + " loading complete in  ---->" + attempts + " seconds");
				System.out.println("document completed");
				break;
			}
		//	logger.debug(pageName + " loading not complete after attempt ---->" + attempts);
			attempts += 1;
		} while (attempts < waitTime);
		if (!documentReady) {
			
		}
	}
	
	public void waitforAngular(WebDriver driver) throws TestException {
		
		/*int attempts = 1;
	    int waitTime=60;*/
try {
	    //waitforPageLoad(driver);
	    NgWebDriver  ng=new NgWebDriver((JavascriptExecutor)driver);	    
	    ng.waitForAngularRequestsToFinish();
}

catch(Exception e)
{
	System.out.println("exception---"+e);
}

	}
	    

	

}
