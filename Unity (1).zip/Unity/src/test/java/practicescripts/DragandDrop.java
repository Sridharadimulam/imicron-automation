package practicescripts;

import static org.testng.Assert.assertFalse;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.internal.WrapsElement;
import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class DragandDrop  extends BaseExtentReport{
	
	

WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular waitall =new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();
//BasePage chr = new BasePage();
//readExcelData oExcelcon = new readExcelData();

/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
String FileName="UnityTestData.xlsx";
String SheetName="UsersPage";*/

@Test
public void DragDrop() throws Exception 
{
	
	//test=report.createTest("TC# 2 :: AddUser"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get("http://demo.guru99.com/test/drag_drop.html");
	
	WebElement from = obrw.findElement(By.xpath("//a[contains(text(),'BANK')]"));
	WebElement To = obrw.findElement(By.xpath("//*[@id='bank']/li"));
	Actions act = new Actions(obrw);
	act.dragAndDrop(from, To).build().perform();
	
	
}
}