package ObjRepo;

public class ObjInfo {
	
	public String ExcelPath=System.getProperty("user.dir") +"/src/test/java/TestData";			
	public String ExcelFile="UnityTestData.xlsx";
	public String DriverPath=System.getProperty("user.dir") +"/src/test/java/Driver/chromedriver.exe";
	public String URL ="http://www.imicrondev.com/QA/Enterprise/Portal";
	//public String URL ="http://unity.imicroncloud.com/techwave/Home/Signin";
	public String XMLPath =System.getProperty("user.dir") +"/src/test/resources/Unity.xml";
	public String HtmlPath=System.getProperty("user.dir") +"/test-output/UnityReport.html";				
	public String[] SheetName = new String[]{"TestScripts","WorkFlows","UsersPage", "Transfer", "Release", "SupportPage","Createtcket","ManageInstance","EditUser","IassRequest","PassRequest","CreateRequest","Usage","Requests","Instanceallocate","Transfer(L1)"};
	
	
	
	//Login Page
	public String Email="//input[@type='email']";
	public String Password="//input[@type='password']";
	public String Submit="//input[@type='submit']";
	
	
	
}
