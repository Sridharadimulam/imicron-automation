package unityscripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class Operations {
	
	WebDriver obrw;
	NewExcelConfig nec=new NewExcelConfig();
	waitforangular waitall =new waitforangular();
	functionLibs fun = new functionLibs();
	waitforangular jswait = new waitforangular();
	ObjInfo oInfo=new ObjInfo();
	//BasePage chr = new BasePage();
	//readExcelData oExcelcon = new readExcelData();

	/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
	String FileName="UnityTestData.xlsx";
	String SheetName="UsersPage";*/

	@Test(priority=1)
	public void CreateUser() throws Exception 
	{
		
		//test=report.createTest("TC# 2 :: AddUser"); 
		System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
		obrw=new ChromeDriver();
		obrw.manage().window().maximize();
		//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
		obrw.get(oInfo.URL);
		//WebDriverWait wait=new WebDriverWait(obrw, 100);
		nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
		
		//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
		obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
		

		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath(oInfo.Email)).sendKeys("sridevi.voleti@techwave.net");
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath(oInfo.Password)).sendKeys("123");
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath(oInfo.Submit)).click();
	Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
		
		if( selectedou)
		
		{
		obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
				
		}
		
		/*for(int i=0;i<=20;i++)
		{*/

		
		jswait.waitforAngular(obrw);
		obrw.findElement(By.xpath("//a[contains(text(),'Operations')]")).click();
		jswait.waitforAngular(obrw);
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr[5]/td[1]")).click();
		jswait.waitforAngular(obrw);
		obrw.findElement(By.xpath("//a[contains(text(),'Monitoring')]")).click();
		
		obrw.switchTo().frame("selfservice");
		
		jswait.waitforAngular(obrw);
		obrw.findElement(By.xpath("//a[contains(@href, '#menu1')]")).click();
		
		
		
		

}
}
