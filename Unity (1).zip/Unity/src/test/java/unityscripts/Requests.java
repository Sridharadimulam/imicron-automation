package unityscripts;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class Requests extends BaseExtentReport{

	
ChromeDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
ObjInfo oInfo=new ObjInfo();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
@Test
public void AddRequest() throws Exception
{
	
	test=report.createTest("TC# 13 :: Request"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[13]);
	
	
	
	 int iRows=nec.rowCount(13);

     System.out.println(iRows);
     for(int i=1;i<=iRows;i++)
    	 
     {
   obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    		
    obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(13, i, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(13, i, 1));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	jswait.waitforAngular(obrw);
	
	
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}
	
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//div[@class='col-sm-3 requests']//div[@class='col-sm-2 icon']")).click();
	
	
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//a[@ng-click='newRequest()']")).click();
	//Thread.sleep(1000);
	
	String Request = nec.GetData(13, i, 2);
	String Questionarie1 =nec.GetData(13,i,3);
	String Questionarie2 =nec.GetData(13,i,4);

	jswait.waitforAngular(obrw);
	if (Request.equals("Compute"))
	{
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//div[@class='col-sm-10']//div[@class='title'][b[text()='"+ Request +"']]/following-sibling::a")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//span[text()='" + Questionarie1 + "']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//span[text()='" + Questionarie2 + "']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[text()='NEXT']")).click();
	
	
	
	}
	else {
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//div[@class='col-sm-10']//div[@class='title'][b[text()='"+ Request +"']]/following-sibling::a")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//span[text()='" + Questionarie1 + "']")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//span[text()='" + Questionarie2 + "']")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//button[text()='NEXT']")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		String Service =nec.GetData(13,i,5);
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//div[text()='"+ Service +"']/preceding::label[1]/span")).click();
		
		obrw.findElement(By.xpath("//button[text()='NEXT']")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
	}
	
	String size = nec.GetData(13, i, 6);
	String OS = nec.GetData(13, i, 7);
	String Cloud = nec.GetData(13, i, 8);
	//System.out.println(size);
	obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ size +"']")).click();
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ OS +"']")).click();
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ Cloud +"']")).click();
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[text()='SUBMIT']")).click();
	Thread.sleep(2000);
	//String Request1 = obrw.findElement(By.xpath("//p[text()='Your request  has been created successfully with id \"']")).getText();
    String Request1 = obrw.findElement(By.xpath("//div[@class='col-sm-12']//p[@class='ng-binding']")).getText();
	//System.out.println(Request1);
	test.pass(Request1);
	
	//if(Request1.startsWith("UN"))
	String requestid;
	String strarray[] =Request1.split(" ");
	
	for(String str:strarray) {
	if (str.contains("UN")) {
		
		str = str.replaceAll("^\"|\"$",""); 
		requestid=str;
		nec.setCellData(13,i, 9, requestid);	
	}
	}
	
	Thread.sleep(1000);
	//Boolean Pass=fun.isElementPresent(obrw,By.xpath("//div[@class='row']//button[@type='button'][contains(text(),'Ok')]"));
	Boolean Paas=fun.isElementPresent(obrw,By.xpath("//div[@id='paas_modal']//div[@class='col-sm-12 text-center']"));
if(Paas)
{
	
	//obrw.findElement(By.xpath("//div[@class='row']//button[@type='button'][contains(text(),'Ok')]")).click();
	obrw.findElement(By.xpath("//div[@id='paas_modal']//div[@class='col-sm-12 text-center']")).click();
}
else {
	
	obrw.findElement(By.xpath("//div[@class='row']//button[@type='button'][contains(text(),'Ok')]")).click();
}
//For loop end
Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
	
}

}
		
}




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
