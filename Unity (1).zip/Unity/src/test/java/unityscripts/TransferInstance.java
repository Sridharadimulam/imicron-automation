package unityscripts;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class TransferInstance  extends BaseExtentReport{

	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();

@Test
public void TransferInstanceL1() throws Exception
{
	
	test=report.createTest("TC# 6 :: TransferInstanceL1"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[6]);
	
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[text()='Get Started']"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='email']"))));
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(6, 1, 0));
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='password']"))));
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(6, 1, 1));
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='submit']"))));
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	Thread.sleep(1000);
	
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}
    	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//a[contains(text(),'Ownership')]")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[@ng-model='searchToggleIaas']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@ng-model='FilterSearchIaas.OrgUnitName']")).sendKeys(nec.GetData(6, 1, 2));
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[@ng-click='applyFilterIaas(FilterSearchIaas)']")).click();
	
	/*Thread.sleep(2000);
	Boolean Data= fun.elementExists(obrw,By.xpath("//td[contains(text(),'No Data Found.')]"));
	 assertFalse(Data,"No Data Found.");*/
	
	//assertFalse(obrw.findElement(By.xpath("//td[contains(text(),'No Data Found.')]")).isDisplayed(),"No Data Found.'");
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tbody//tr[1]//td[4]//button[1]")).click();
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//span[@class='select2-arrow ui-select-toggle']")).click();
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//input[@type='search']")).sendKeys(nec.GetData(6, 1, 3));
	
	WebElement textbox = obrw.findElement(By.xpath("//input[@type='search']"));
	textbox.sendKeys(Keys.ENTER);
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//div[@class='modal-dialog w-350']//input[@ng-click='setFromDate(transferServer)']")).clear();
	obrw.findElement(By.xpath("//div[@class='modal-dialog w-350']//input[@ng-click='setFromDate(transferServer)']")).sendKeys(nec.GetData(6, 1, 4));
	
	obrw.findElement(By.xpath("//div[@class='modal-dialog w-350']//input[@ng-click='setToDate(transferServer)']")).clear();
	obrw.findElement(By.xpath("//div[@class='modal-dialog w-350']//input[@ng-click='setToDate(transferServer)']")).sendKeys(nec.GetData(6, 1, 5));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[@id='transfer-confirm']")).click();
	
	
	Thread.sleep(1000);
	String success = obrw.findElement(By.xpath("//div[@id='transfer-approval-modal']//div[@class='col-sm-12']")).getText();
	System.out.println(success);
	
	test.pass(success);

	
	Thread.sleep(1000);
	if(obrw.findElement(By.xpath("//div[@id='transfer-modal']//button[@type='button']")).isDisplayed())
	{
	obrw.findElement(By.xpath("//div[@id='transfer-modal']//button[@type='button']")).click();
	}
	else if(obrw.findElement(By.xpath("//div[@id='transfer-approval-modal']//button[@type='button']")).isDisplayed())
	{
	obrw.findElement(By.xpath("//div[@id='transfer-approval-modal']//button[@type='button']")).click();
	}
	 Thread.sleep(1000);
  	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
  	Thread.sleep(1000);
  	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
  	obrw.close();
}
	
	//@Test(priority=3)
	@Test(dependsOnMethods = { "TransferInstanceL1" })
	public void Authorize() throws Exception
	{
		
		test=report.createTest("TC# 6.1 :: Authorize"); 
		System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
		obrw=new ChromeDriver();
		obrw.manage().window().maximize();
		obrw.get(oInfo.URL);
		//WebDriverWait wait=new WebDriverWait(obrw, 100);
		nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[6]);
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(6, 1, 6));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(6, 1, 1));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	Thread.sleep(1000);
	
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//div[@class='col-sm-4 requests']//div[@class='col-sm-2 icon']")).click();
	jswait.waitforAngular(obrw);
	//Thread.sleep(1000);
	obrw.findElement(By.xpath("//button[@ng-model='searchTogglepending'] ")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    obrw.findElement(By.xpath("//div[@class='row mt-20']//div[@class='col-sm-6']//select[@name='usecase']")).click();
	Select roles=new Select(obrw.findElement(By.xpath("//div[@class='row mt-20']//div[@class='col-sm-6']//select[@name='usecase']")));
	roles.selectByVisibleText(nec.GetData(6, 1,7));
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//div[@class='col-sm-5 filter-buttons pull-right mt-30']//button[@type='button'][contains(text(),'Apply')]")).click();
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//tbody//tr[1]//td[8]//span[2]//span[3]")).click();
	
	 Thread.sleep(1000);
  	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
  	Thread.sleep(1000);
  	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
  	obrw.close();

}
}
