package unityscripts;


import static org.testng.Assert.assertFalse;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.internal.WrapsElement;
import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class AddUser  extends BaseExtentReport{
	
	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular waitall =new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();
//BasePage chr = new BasePage();
//readExcelData oExcelcon = new readExcelData();

/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
String FileName="UnityTestData.xlsx";
String SheetName="UsersPage";*/

@Test(priority=1)
public void CreateUser() throws Exception 
{
	
	test=report.createTest("TC# 2 :: AddUser"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	obrw.get(oInfo.URL);
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[2]);
	
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	

	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Email)).sendKeys(nec.GetData(2, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Password)).sendKeys(nec.GetData(2, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Submit)).click();
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}

	 Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Users')]")).click();
	/*wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@ng-click=\"addingnewuser()\"]"))));
	obrw.findElement(By.xpath("//a[@ng-click=\"addingnewuser()\"]")).click();*/
	
	/*wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//*[@id=\"addUser\"]/div/div/div[2]/form/div[4]/div/div/div[1]/div/div[2]/div/select"))));
    obrw.findElement(By.xpath("//*[@id=\"addUser\"]/div/div/div[2]/form/div[4]/div/div/div[1]/div/div[2]/div/select")).click();*/
    
	 int iRows=nec.rowCount(2);

     System.out.println(iRows);
     for(int i=1;i<=iRows;i++)
    	 
     {
          
    	 Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[@ng-click='addingnewuser()']")).click();
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//div[@id='addUser']//input[@name='username']")).sendKeys(nec.GetData(2, i, 2));
	
	
	Thread.sleep(1000);
	String emailid = nec.GetData(2, i, 3);
	obrw.findElement(By.xpath("//div[@id='addUser']//input[@name='userEmail']")).sendKeys(emailid);
	Thread.sleep(2000);
	
	//assertFalse(obrw.findElement(By.xpath("//div[@id='addUser']//span[contains(text(),'Please Enter Valid Email')]")).isDisplayed(),"Please Enter Valid Email");
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//div[@id='addUser']//input[@name='displayName']")).sendKeys(nec.GetData(2, i, 4));
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    obrw.findElement(By.xpath("//select[@ng-model='group.roles']")).click();
    
	Select roles=new Select(obrw.findElement(By.xpath("//select[@ng-model='group.roles']")));
	roles.selectByVisibleText(nec.GetData(2, i, 5));
    
	Thread.sleep(1000);
	
    obrw.findElement(By.xpath("//select[@ng-model='group.OUName']")).click();
   
	Select OUName=new Select(obrw.findElement(By.xpath("//select[@ng-model='group.OUName']")));
	OUName.selectByVisibleText(nec.GetData(2, i, 6));
    
	if(obrw.findElement(By.xpath("//div[@id='addUser']//span[contains(text(),'Please Enter Valid Email')]")).isDisplayed())
			{
		SoftAssert s_assert = new SoftAssert();
		s_assert.assertEquals(obrw.findElement(By.xpath("//div[@id='addUser']//span[contains(text(),'Please Enter Valid Email')]")).isDisplayed(),"Please Enter Valid Email");
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//div[@id='addUser']//div[@class='modal-header']//button[@type='button']")).click();
		test.fail("Please Enter Valid Email");
	}
	else
	{
	obrw.findElement(By.xpath("//button[@ng-click='addUser(user)']")).click();
	Thread.sleep(1000);

	if(obrw.findElement(By.xpath("//p[contains(text(),'User Added Successfully')]")).isDisplayed())
    {
    String Useradded = obrw.findElement(By.xpath("//p[contains(text(),'User Added Successfully')]")).getText();
    System.out.println(Useradded);
   // nec.setCellData(2, i, 7, Useradded);
    Thread.sleep(1000);
    obrw.findElement(By.xpath("//div[@id='addusergroup']//button[@type='button']")).click();
    test.pass(emailid+" "+Useradded);
    }
    else if (obrw.findElement(By.xpath("//p[contains(text(),'User with same E-mail already exists!')]")).isDisplayed())
    {
           String alreadyexist = obrw.findElement(By.xpath("//p[contains(text(),'User with same E-mail already exists!')]")).getText();
           System.out.println(alreadyexist);
           //nec.setCellData(1, i, 7, alreadyexist);
           Thread.sleep(1000);
           obrw.findElement(By.xpath("//div[@id='addassociate']//button[@type='button']")).click();
           Thread.sleep(1000);
           obrw.findElement(By.xpath("//div[@id='addUser']//div[@class='modal-header']//button[@type='button']")).click();
           //assertFalse(obrw.findElement(By.xpath("//p[contains(text(),'User with same E-mail already exists!')]")).isDisplayed(),"User with same E-mail already exists!'");
           test.fail(emailid+" "+alreadyexist);
    }
           
    }
	
    }
     
    Thread.sleep(1000);
 	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
 	Thread.sleep(1000);
 	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
 	obrw.close();

}

}

   
   
	
	
	




	




 

		





	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
