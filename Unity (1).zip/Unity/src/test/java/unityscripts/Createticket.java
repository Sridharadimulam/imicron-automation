package unityscripts;



import java.util.ArrayList;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.Test;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class Createticket  extends BaseExtentReport{
	
	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular waitall =new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();
waitforangular jswait = new waitforangular();



@Test(priority=1)
public void Ticket() throws Exception 
{
	//JSWaiter.setDriver(obrw);
	test=report.createTest("TC# 9 :: Createticket"); 
	
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	obrw.get(oInfo.URL);
	
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[6]);
	
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	

	//JSWaiter.sleep(1000);
	
	obrw.findElement(By.xpath(oInfo.Email)).sendKeys(nec.GetData(6, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Password)).sendKeys(nec.GetData(6, 1, 1));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Submit)).click();
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}

	 Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Support')]")).click();
	jswait.waitforAngular(obrw);
	String New = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope']")).getText();
    int count = Integer.parseInt(New.replaceAll("\\D", ""));
    System.out.println(count);

	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[text()='Create ticket']")).click();
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@name='Title']")).sendKeys(nec.GetData(6, 1, 2));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//textarea[@name='Description']")).sendKeys(nec.GetData(6, 1, 3));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[text()='Add']")).click();
	 //assertFalse(obrw.findElement(By.xpath("//span[contains(text(),'Something went wrong.Please try again')]")).isDisplayed(),"Something went wrong.Please try again");
	jswait.waitforAngular(obrw);
	String success = obrw.findElement(By.xpath("//div[@class='col-sm-12 ng-binding']")).getText();
	test.pass(success);
	obrw.findElement(By.xpath("//div[@id='bpmTicketnumber-modal']//button[@type='button']")).click();
	//JSWaiter.waitJQueryAngular();
	
	String count1 = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope']")).getText();
    int Newcount = Integer.parseInt(count1.replaceAll("\\D", ""));
    System.out.println(Newcount);
    String Inprogress = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope countprogress']")).getText();	       
    int Inprogresscount = Integer.parseInt(Inprogress.replaceAll("\\D", ""));
    System.out.println(Inprogresscount);
    
    if(Newcount==count+1)
    {
    System.out.println(Newcount);
    test.pass("Newcount Updated successfully");
    }
    else {
    	 System.out.println(count);
    	 test.fail("New count not matched");
    }
	
	String ticketno = obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).getText();
	System.out.println(ticketno);
	
	JavascriptExecutor js = (JavascriptExecutor) obrw;  
	js.executeScript("window.open()");
//	((JavascriptExecutor)obrw).executeScript("window.open()");
	ArrayList<String> tabs = new ArrayList<String>(obrw.getWindowHandles());
	obrw.switchTo().window(tabs.get(1));
	
	obrw.get("https://dev-imicroncare.bpmonline.com/ ");
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//input[@id='loginEdit-el']")).sendKeys(nec.GetData(6, 1, 4));
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//input[@id='passwordEdit-el']")).sendKeys(nec.GetData(6, 1, 5));
	
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//span[@id='t-comp12-textEl']")).click();
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//div[text()=' Service Request ']")).click();
	//jswait.waitforAngular(obrw);
	Thread.sleep(20000);
	//JSWaiter.waitJQueryAngular();

Boolean Exist=fun.isElementPresent(obrw,By.xpath("//label[@class='t-label filter-caption-label filter-element-with-right-space']"));
	
	if( Exist)
	{
		obrw.findElement(By.xpath("//span[@class='t-btn-wrapper t-btn-no-text-padding t-btn-style-transparent filter-remove-button']")).click();
		
	}
	
	obrw.findElement(By.xpath("//span[@data-item-marker='filterButton']")).click();
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//li[@data-item-marker='Add filter']")).click();
	obrw.findElement(By.xpath("//input[@id='customFilterSectionModuleV2_CaseSection_QuickFilterModuleV2-el']")).sendKeys(ticketno);
	
	obrw.findElement(By.xpath("//span[@data-item-marker='applyButton']")).click();
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[@data-column='Number']")).click();
	jswait.waitforAngular(obrw);
	Thread.sleep(30000);

	//obrw.manage().timeouts().pageLoadTimeout(1000, TimeUnit.SECONDS);
	
	obrw.findElement(By.xpath("//span[text()='In progress']")).click();
	obrw.switchTo().window(tabs.get(0));
	obrw.navigate().refresh();
	jswait.waitforAngular(obrw);
	String Inprogressnew = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope countprogress']")).getText();	       
    int Inprogressnewcount = Integer.parseInt(Inprogressnew.replaceAll("\\D", ""));
    System.out.println(Inprogressnewcount);
    
    if(Inprogressnewcount==Inprogresscount+1)
    {
    System.out.println(Inprogressnewcount);
    test.pass("Inprogress count updated successfully");
    }
    else {
    	 System.out.println(Inprogresscount);
    	 test.fail("inprogress not matched");
    }
    
    obrw.switchTo().window(tabs.get(1));
	obrw.findElement(By.xpath("//span[@id='profile-user-button-wrapperEl']")).click();
	obrw.findElement(By.xpath("//li[@id='exit-menu-item']")).click();
	
	obrw.switchTo().window(tabs.get(1)).close();
	 obrw.switchTo().window(tabs.get(0));
	  Thread.sleep(1000);
	 	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
	 	Thread.sleep(1000);
	 	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
	 	obrw.close();
	
}
}