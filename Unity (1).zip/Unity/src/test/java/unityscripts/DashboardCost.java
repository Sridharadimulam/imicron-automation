package unityscripts;


import static org.testng.Assert.assertFalse;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class DashboardCost  extends BaseExtentReport{
	
	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();
//BasePage chr = new BasePage();
//readExcelData oExcelcon = new readExcelData();

/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
String FileName="UnityTestData.xlsx";
String SheetName="UsersPage";*/

@Test(priority=1)
public void Cost() throws Exception 
{
	
	test=report.createTest("TC# 2 :: Cost"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	obrw.get(oInfo.URL);
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[12]);
	
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	

	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Email)).sendKeys(nec.GetData(12, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Password)).sendKeys(nec.GetData(12, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Submit)).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//a[contains(text(),'Ownership')]")).click();
	obrw.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	List<WebElement> allpages = obrw.findElements(By.xpath("//td[@ng-show='totalIAASInstances > itemsPerPage']//a "));
    System.out.println("Total pages :" +allpages.size());
    for(int i=0; i<=(allpages.size()); i++)
    	
        {
    	Thread.sleep(1000);
    	//Boolean match=false;
    	List<WebElement> allrows = obrw.findElements(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tbody//tr//td[1]//div[1]"));
            for(int row=1; row<=allrows.size(); row++)
                {
            	
                    System.out.println("Total rows :" +allrows.size()); 
                    obrw.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
                     obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tbody//tr["+ row +"]//td[1]//div[1]")).click();
                     Thread.sleep(1000);
                    String cost = obrw.findElement(By.xpath("//div[contains(text(),'Instance Price:')]/following-sibling::div")).getText();
                    System.out.print(cost);
                    obrw.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
                    obrw.findElement(By.xpath("//button[text()='BACK']")).click();
             
	
}
        }
}
}