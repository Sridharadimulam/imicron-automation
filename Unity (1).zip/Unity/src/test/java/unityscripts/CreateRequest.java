package unityscripts;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.model.Log;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class CreateRequest extends BaseExtentReport{

	
ChromeDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
ObjInfo oInfo=new ObjInfo();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
@Test
public void AddRequest() throws Exception
{
	
	test=report.createTest("TC# 13 :: CreateRequest"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[11]);
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(11, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(11, 1, 1));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	jswait.waitforAngular(obrw);
	
	
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}
	
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//div[@class='col-sm-3 requests']//div[@class='col-sm-2 icon']")).click();
	
	/* int iRows=nec.rowCount(5);

     System.out.println(iRows);
     for(int i=1;i<=iRows;i++)
    	 
     {*/
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//a[@ng-click='newRequest()']")).click();
	//Thread.sleep(1000);
	
	String Request = nec.GetData(11, 1, 2);
	String Questionarie1 =nec.GetData(11,1,3);
	String Questionarie2 =nec.GetData(11,1,4);

	jswait.waitforAngular(obrw);
	if (Request.equals("Compute"))
	{
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//div[@class='col-sm-10']//div[@class='title'][b[text()='"+ Request +"']]/following-sibling::a")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//span[text()='" + Questionarie1 + "']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//span[text()='" + Questionarie2 + "']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[text()='NEXT']")).click();
	
	}
	else {
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//div[@class='col-sm-10']//div[@class='title'][b[text()='"+ Request +"']]/following-sibling::a")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//span[text()='" + Questionarie1 + "']")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//span[text()='" + Questionarie2 + "']")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//button[text()='NEXT']")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		String Service =nec.GetData(11,1,5);
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath("//div[text()='"+ Service +"']/preceding::label[1]/span")).click();
		
		obrw.findElement(By.xpath("//button[text()='NEXT']")).click();
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
	}
	
	String size = nec.GetData(11, 1, 6);
	String OS = nec.GetData(11, 1, 7);
	String Cloud = nec.GetData(11, 1, 8);
	//System.out.println(size);
	obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ size +"']")).click();
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ OS +"']")).click();
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ Cloud +"']")).click();
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[text()='SUBMIT']")).click();
	Thread.sleep(2000);
	//String Request1 = obrw.findElement(By.xpath("//p[text()='Your request  has been created successfully with id \"']")).getText();
    String Request1 = obrw.findElement(By.xpath("//div[@class='col-sm-12']//p[@class='ng-binding']")).getText();
	//System.out.println(Request1);
	test.pass(Request1);
	
	//if(Request1.startsWith("UN"))
	String requestid;
	String strarray[] =Request1.split(" ");
	
	for(String str:strarray) {
	if (str.contains("UN")) {
		
		str = str.replaceAll("^\"|\"$",""); 
		requestid=str;
		nec.setCellData(11,1, 9, requestid);	
	}
	}
	
	Thread.sleep(1000);
	//Boolean Pass=fun.isElementPresent(obrw,By.xpath("//div[@class='row']//button[@type='button'][contains(text(),'Ok')]"));
	Boolean Pass=fun.isElementPresent(obrw,By.xpath("//div[@id='paas_modal']//div[@class='col-sm-12 text-center']"));
if(Pass)
{
	
	//obrw.findElement(By.xpath("//div[@class='row']//button[@type='button'][contains(text(),'Ok')]")).click();
	obrw.findElement(By.xpath("//div[@id='paas_modal']//div[@class='col-sm-12 text-center']")).click();
}
else {
	
	obrw.findElement(By.xpath("//div[@class='row']//button[@type='button'][contains(text(),'Ok')]")).click();
}
//For loop end
    
	jswait.waitforAngular(obrw);
 	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
 	jswait.waitforAngular(obrw);
 	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
 	obrw.close();
}

@Test(dependsOnMethods = { "AddRequest" })
public void ProxyAuthorize() throws Exception
{


	test=report.createTest("TC# 13.2 :: ProxyAuthorize"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[11]);
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(11, 1, 10));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(11, 1, 11));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	jswait.waitforAngular(obrw);
	Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}
	
	//obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
	
	obrw.findElement(By.xpath("//div[@class='col-sm-3 requests']//div[@class='col-sm-2 icon']")).click();
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Authorize Requests')]")).click();
	jswait.waitforAngular(obrw);
	
	List<WebElement> sCellValue = obrw.findElements(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr/td[1]"));
	 sCellValue.size();
	 
	 int size = sCellValue.size();
	/*String sCellValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr[1]/td[1]")).getText();
	System.out.println(sCellValue);*/
	 
	String sRowValue = nec.GetData(11, 1, 9);
	
	//First loop will find the 'Request ID' in the first column
	for (int i=1;i<=size;i++){
		String sValue = null;
		sValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[1]")).getText();
		if(sValue.equalsIgnoreCase(sRowValue)){
			
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[8]/span[2]")).click();
			//obrw.findElement(By.xpath("//span[@class='ng-binding'][contains(text(),'Authorize')]")).click();
		break;	
		}	
	}
	
	obrw.findElement(By.xpath("//a[contains(text(),'Similar Configuration')]")).click();
	Thread.sleep(1000);
	
	Boolean Similar=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tr[@ng-click='selectRequest(similarmatch) || reservedDetails(similarmatch)']"));
	similar:
	if( Similar)
	   
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']")).isDisplayed())
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).isDisplayed())
	{
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).click();
		
        obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(11, 1, 12));
		
		obrw.findElement(By.xpath("//button[text()='Allocate']")).click();
		Thread.sleep(2000);
		obrw.findElement(By.xpath("//a[contains(text(),'Authorize Requests')]")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[1]/td[1]/div[1]")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[@ng-click='getInstanceDetails(ticketinfo)']")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[contains(text(),'Request History')]")).click();
		
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).click();
		Thread.sleep(1000);
		String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
		Thread.sleep(1000);
		test.pass(log);
		//if( Similar)
		break similar;
	}  
	
	Boolean Nodata=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//td[text()='No Data Found']"));
	if(Nodata) 
		{
	obrw.findElement(By.xpath("//a[contains(text(),'Same Configuration')]")).click();
	Thread.sleep(1000);
	
	
	
	//obrw.findElement(By.xpath("//a[contains(text(),'Same Configuration')]")).click();
	Boolean Same=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']"));
	same:
		if( Same)
		   
		//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']")).isDisplayed())
		//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).isDisplayed())
		{
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).click();
			
	        obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(11, 1, 12));
			
			obrw.findElement(By.xpath("//button[text()='Allocate']")).click();
			Thread.sleep(2000);
			obrw.findElement(By.xpath("//a[contains(text(),'Authorize Requests')]")).click();
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[1]/td[1]/div[1]")).click();
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//a[@ng-click='getInstanceDetails(ticketinfo)']")).click();
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//a[contains(text(),'Request History')]")).click();
			
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).click();
			Thread.sleep(1000);
			String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
			Thread.sleep(1000);
			test.pass(log);
			break same;
			
		}
	
	
		else if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//td[text()='No Data Found']")).isDisplayed())
		{
			obrw.findElement(By.xpath("//button[contains(text(),'Procure new Instance')]")).click();
			Thread.sleep(1000);
	       Boolean procure=fun.isElementPresent(obrw,By.xpath("//div[@class='modal-body ng-pristine ng-untouched ng-valid ng-not-empty']//div[1]"));
			if( procure)
			{
				Thread.sleep(1000); 
				String proc = obrw.findElement(By.xpath("//div[@class='modal-body ng-pristine ng-untouched ng-valid ng-not-empty']//div[1]")).getText();
				Thread.sleep(1000);
				test.pass(proc);
				obrw.findElement(By.xpath("//button[text()='OK']")).click();
				
		Thread.sleep(1000);
		jswait.waitforAngular(obrw);
		obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
		jswait.waitforAngular(obrw);
		obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
	   obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	   test=report.createTest("TC# 13.3 :: Authorize");
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(11, 1, 13));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(11, 1, 14));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	jswait.waitforAngular(obrw);
   Boolean selectedou1=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	if( selectedou1)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}
	
	//obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
	
	obrw.findElement(By.xpath("//div[@class='col-sm-3 requests']//div[@class='col-sm-2 icon']")).click();
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Authorize Requests')]")).click();
	jswait.waitforAngular(obrw);
	
	List<WebElement> sCellValue1 = obrw.findElements(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr/td[1]"));
	 sCellValue1.size();
	 
	 int size1 = sCellValue.size();
	/*String sCellValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr[1]/td[1]")).getText();
	System.out.println(sCellValue);*/
	 
	String sRowValue1 = nec.GetData(11, 1, 9);
	
	//First loop will find the 'Request ID' in the first column
	for (int i=1;i<=size1;i++){
		String sValue = null;
		sValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[1]")).getText();
		if(sValue.equalsIgnoreCase(sRowValue1)){
			
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[8]/span[2]")).click();
			//obrw.findElement(By.xpath("//span[@class='ng-binding'][contains(text(),'Authorize')]")).click();
		break;	
		}	
	}
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Same Configuration')]")).click();
	
	Boolean Same1=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']"));
		
		if( Same1)
		   
		//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']")).isDisplayed())
		//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).isDisplayed())
		{
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).click();
			
	        obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(11, 1, 12));
			
			obrw.findElement(By.xpath("//button[text()='Allocate']")).click();
			jswait.waitforAngular(obrw);
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[1]/td[1]/div[1]")).click();
			jswait.waitforAngular(obrw);
			obrw.findElement(By.xpath("//a[@ng-click='getInstanceDetails(ticketinfo)']")).click();
			jswait.waitforAngular(obrw);
			obrw.findElement(By.xpath("//a[contains(text(),'Request History')]")).click();
			
			jswait.waitforAngular(obrw);
			obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).click();
			jswait.waitforAngular(obrw);
			String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
			jswait.waitforAngular(obrw);
			test.pass(log);
			
			
		}
		Boolean Nodata1=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//td[text()='No Data Found']"));
		if(Nodata1) 
			{
		obrw.findElement(By.xpath("//a[contains(text(),'Similar Configuration')]")).click();
		Thread.sleep(1000);
	   Boolean Similar1=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tr[@ng-click='selectRequest(similarmatch) || reservedDetails(similarmatch)']"));
		
		if( Similar1)
		   
		//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']")).isDisplayed())
		//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).isDisplayed())
		{
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).click();
			
	        obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(10, 1, 12));
			
			obrw.findElement(By.xpath("//button[text()='Allocate']")).click();
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[1]/td[1]/div[1]")).click();
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//a[@ng-click='getInstanceDetails(ticketinfo)']")).click();
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//a[contains(text(),'Request History')]")).click();
			
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).click();
			Thread.sleep(1000);
			String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
			Thread.sleep(1000);
			test.pass(log);
		}
		else if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//td[text()='No Data Found']")).isDisplayed())
		{
			obrw.findElement(By.xpath("//button[contains(text(),'Procure new Instance')]")).click();
			Thread.sleep(1000);
         	obrw.findElement(By.xpath("//input[@name='Title']")).sendKeys(nec.GetData(10, 1, 15));
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//textarea[@name='Description']")).sendKeys(nec.GetData(10, 1, 16));
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//button[contains(text(),'Add')]")).click();
			obrw.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			jswait.waitforAngular(obrw);
			String Ticket = obrw.findElement(By.xpath("//div[@id='bpmTicketnumber-modal']//div[@class='modal-body']")).getText();
			System.out.println(Ticket);
			Thread.sleep(1000);
			test.pass(Ticket);
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//div[@id='bpmTicketnumber-modal']//button[@type='button']")).click();
		}
			}
			}
		}
			
		}
			Thread.sleep(1000);
			jswait.waitforAngular(obrw);
			obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
			jswait.waitforAngular(obrw);
			obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
			obrw.close();

			
	
		}
			

}






 

		





	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
