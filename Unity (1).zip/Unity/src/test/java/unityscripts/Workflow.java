package unityscripts;



import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;
public class Workflow  extends BaseExtentReport{

	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
ObjInfo oInfo=new ObjInfo();
functionLibs fun = new functionLibs();


@Test(priority=1)
public void Workflows() throws Exception
{
	//BasicConfigurator.configure();
	test=report.createTest("TC# 1 :: Workflows"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	//obrw.get("http://www.imicrondev.com/QA/Enterprise/Portal");
	obrw.get(oInfo.URL);
	WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[1]);
	
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[text()='Get Started']"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='email']"))));
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(1, 1, 0));
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='password']"))));
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(1, 1, 1));
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='submit']"))));
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	Thread.sleep(1000);
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}

	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Workflows')]")).click();
	
	/*obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//a[contains(text(),'Workflow')]")).click();*/
	
	
	
	int iRows=nec.rowCount(1);
	
	 
    System.out.println(iRows);
    for(int i=1;i<=iRows;i++)
   	 
    {
	Thread.sleep(1000);
	
	
	//To calculate no of rows In table.
	//int rows_count = rows_table.size(); 
	//Loop will execute till the last row of table.
	
    //No.of rows 
	String Activity = nec.GetData(1, i, 2);
	
	Select Workflow=new Select(obrw.findElement(By.xpath("//div[@class='collapsePanel']//div[1]//table[1]//tbody[1]//tr//td[1]//span[text()='"+Activity+"']/following::select[1]")));
	Workflow.selectByVisibleText(nec.GetData(1, i, 3));
	 
	 obrw.findElement(By.xpath("//div[@class='collapsePanel']//div[1]//table[1]//tbody[1]//tr//td[1]//span[text()='"+Activity+"']/following::button[1]")).click();
	 
	 Thread.sleep(1000);
	 String success = obrw.findElement(By.xpath("//div[@id='success-modal1']//div[@class='col-sm-12']")).getText();
	// nec.setCellData(1, i, 4, success);
	 Thread.sleep(1000);
	 obrw.findElement(By.xpath("//div[@id='success-modal1']//button[@type='button']")).click();
	 test.pass(success);
}
}


@Test(priority=2)

    public void UserGroup() throws Exception
    {
	
	test=report.createTest("TC# 1.2 :: UserGroup");
  
    	int iRows=nec.rowCount(1);
    	
   	 
        System.out.println(iRows);
        for(int i=1;i<=iRows;i++)
       	 
        {
    	Thread.sleep(1000);
    	
    	
    	//To calculate no of rows In table.
    	//int rows_count = rows_table.size(); 
    	//Loop will execute till the last row of table.
    	
        //No.of rows 
    	String Activity1 = nec.GetData(1, i, 4);
    	
    	Select Workflow=new Select(obrw.findElement(By.xpath("//div[@class='collapsePanel']//div[2]//table[1]//tbody[1]//tr//td[1]//span[text()='"+Activity1+"']/following::select[1]")));
    	Workflow.selectByVisibleText(nec.GetData(1, i, 5));
    	
    	obrw.findElement(By.xpath("//div[@class='collapsePanel']//div[2]//table[1]//tbody[1]//tr//td[1]//span[text()='"+Activity1+"']/following::button[1]")).click();
   	 
   	 Thread.sleep(1000);
   	 String success = obrw.findElement(By.xpath("//div[@id='success-modal1']//div[@class='col-sm-12']")).getText();
   	// nec.setCellData(1, i, 4, success);
   	 Thread.sleep(1000);
   	 obrw.findElement(By.xpath("//div[@id='success-modal1']//button[@type='button']")).click();
   	Thread.sleep(1000);
   	 test.pass(success);
   
        }
  
        Thread.sleep(1000);
     	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
     	Thread.sleep(1000);
     	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
     	obrw.close();

}

}










	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
