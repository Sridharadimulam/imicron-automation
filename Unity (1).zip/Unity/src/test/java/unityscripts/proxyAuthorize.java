package unityscripts;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;
public class proxyAuthorize extends BaseExtentReport{

	
ChromeDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
ObjInfo oInfo=new ObjInfo();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
@Test

public void Authorize() throws Exception
{
	
	test=report.createTest("TC# 7.2 :: Authorize"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[10]);
	//waitall.waitforAngular(obrw);
	
	//waitall.waitforPageLoad(obrw);
	
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(10, 1, 9));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys("123");
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	jswait.waitforAngular(obrw);
	
	//obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
	
	obrw.findElement(By.xpath("//div[@class='col-sm-3 requests']//div[@class='title']")).click();
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Authorize Requests')]")).click();
	jswait.waitforAngular(obrw);
	
	//Thread.sleep(50000);
	jswait.waitforAngular(obrw);
	List<WebElement> sCellValue = obrw.findElements(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr/td[1]"));
	 sCellValue.size();
	 
	 int size = sCellValue.size();
	/*String sCellValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr[1]/td[1]")).getText();
	System.out.println(sCellValue);*/
	String sRowValue = nec.GetData(10, 1, 8);
	
	//First loop will find the 'Request ID' in the first column
	for (int i=1;i<=size;i++){
		String sValue = null;
		sValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[1]")).getText();
		if(sValue.equalsIgnoreCase(sRowValue)){
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[8]/span[2]")).click();
			//obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[1]")).click();
			
			//obrw.findElement(By.xpath("//span[@class='ng-binding'][contains(text(),'Authorize')]")).click();
		break;	
		}	
	}
	
	obrw.findElement(By.xpath("//a[contains(text(),'Same Configuration')]")).click();
	
Boolean Same=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']"));
	
	if( Same)
	   
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']")).isDisplayed())
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).isDisplayed())
	{
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).click();
		
        obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(10, 1, 10));
		
		obrw.findElement(By.xpath("//button[text()='Allocate']")).click();
		Thread.sleep(2000);
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[1]/td[1]/div[1]")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[@ng-click='getInstanceDetails(ticketinfo)']")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[contains(text(),'Request History')]")).click();
		
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).click();
		
		String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
		Thread.sleep(1000);
		test.pass(log);
		
		
	}
	Boolean Nodata=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//td[text()='No Data Found']"));
	if(Nodata) 
		{
	obrw.findElement(By.xpath("//a[contains(text(),'Similar Configuration')]")).click();
	Thread.sleep(1000);
    Boolean Similar=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tr[@ng-click='selectRequest(similarmatch) || reservedDetails(similarmatch)']"));
	
	if( Similar)
	   
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']")).isDisplayed())
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).isDisplayed())
	{
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).click();
		
        obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(10, 1, 10));
		
		obrw.findElement(By.xpath("//button[text()='Allocate']")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[1]/td[1]/div[1]")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[@ng-click='getInstanceDetails(ticketinfo)']")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[contains(text(),'Request History')]")).click();
		
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).click();
		
		String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
		Thread.sleep(1000);
		test.pass(log);
	}
	else if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//td[text()='No Data Found']")).isDisplayed())
	{
		obrw.findElement(By.xpath("//button[contains(text(),'Procure new Instance')]")).click();
		Thread.sleep(1000);
       Boolean procure=fun.isElementPresent(obrw,By.xpath("//div[@class='modal-body ng-pristine ng-untouched ng-valid ng-not-empty']//div[1]"));
		if( procure)
		{
			obrw.findElement(By.xpath("//button[text()='OK']")).click();
		}
		else
		{
		obrw.findElement(By.xpath("//input[@name='Title']")).sendKeys(nec.GetData(10, 1, 11));
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//textarea[@name='Description']")).sendKeys(nec.GetData(10, 1, 12));
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//button[contains(text(),'Add')]")).click();
	}
	}
	
		}
	Thread.sleep(1000);
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
	obrw.close();
	}

	}
