package unityscripts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class SupportPage  extends BaseExtentReport{
	
	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular waitall =new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();
waitforangular jswait = new waitforangular();
//BasePage chr = new BasePage();
//readExcelData oExcelcon = new readExcelData();

/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
String FileName="UnityTestData.xlsx";
String SheetName="UsersPage";*/

@Test(priority=1)
public void Support() throws Exception 
{
	
	test=report.createTest("TC# 3 :: SupportPage"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	obrw.get(oInfo.URL);
	
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[5]);
	
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	

	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Email)).sendKeys(nec.GetData(5, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Password)).sendKeys(nec.GetData(5, 1, 1));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Submit)).click();
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}

	 Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Support')]")).click();
	
	 Thread.sleep(1000);
	    obrw.findElement(By.xpath("//input[@placeholder='From']")).clear();
		obrw.findElement(By.xpath("//input[@placeholder='From']")).sendKeys(nec.GetData(5, 1, 2));
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//input[@placeholder='To']")).clear();
		obrw.findElement(By.xpath("//input[@placeholder='To']")).sendKeys(nec.GetData(5, 1, 3));
		
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//span[@class='select2-arrow ui-select-toggle']")).click();
		
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//input[@type='search']")).sendKeys(nec.GetData(5, 1, 4));
		Thread.sleep(1000);
		WebElement textbox = obrw.findElement(By.xpath("//input[@type='search']"));
		textbox.sendKeys(Keys.ENTER);

			obrw.findElement(By.xpath("//button[contains(text(),'Search')]")).click();
			jswait.waitforAngular(obrw);
			//new Count
		   String New = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope']")).getText();
	       int newcount = Integer.parseInt(New.replaceAll("\\D", ""));
	       System.out.println(newcount);
	       //In Progress
	       String Inprogress = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope countprogress']")).getText();	       
	       int Inprogresscount = Integer.parseInt(Inprogress.replaceAll("\\D", ""));
	       System.out.println(Inprogresscount);
	       Thread.sleep(1000);
	     //Closed
	       String Closed = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope countclosed']")).getText();	       
	       int Closedcount = Integer.parseInt(Closed.replaceAll("\\D", ""));
	       System.out.println(Closedcount);
	       Thread.sleep(1000);
	     //Cancelled
	       String Cancelled = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope countcancel']")).getText();	       
	       int Cancelledcount = Integer.parseInt(Cancelled.replaceAll("\\D", ""));
	       System.out.println(Cancelledcount);
	       Thread.sleep(1000);
	       //sum of total tickets
	       int sum = newcount+Inprogresscount+Closedcount+Cancelledcount;
	       System.out.println(sum);
	       Thread.sleep(1000);
	       
	       int totaltickets=0;
	       Boolean Totaltickets=fun.isElementPresent(obrw,By.xpath("//h4[@class='col-sm-10 ng-binding']"));	
	   	if( Totaltickets)
	   	
	   	{	
	      
	       String Tickets=obrw.findElement(By.xpath("//h4[@class='col-sm-10 ng-binding']")).getText();
	       int Total = Integer.parseInt(Tickets.replaceAll("\\D", ""));
	       System.out.println("insatnces -->"+Total);
	       totaltickets=totaltickets+Total;
	   	}
	       

	       if(sum==totaltickets)
	       {
	    	   System.out.println("pass");
	    	   test.pass("Total tickets are matched");
	       }
	       else
	       {
	    	   System.out.println("Fail");
	    	   test.fail("Total tickets not matched");
	       }

	       Thread.sleep(1000);
       	jswait.waitforAngular(obrw);
       	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
       	jswait.waitforAngular(obrw);
       	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
       	obrw.close();
}
	
	
}


        

	       
	  
