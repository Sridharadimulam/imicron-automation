package unityscripts;



import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class DeleteUser  extends BaseExtentReport{
	
	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();
//BasePage chr = new BasePage();
//readExcelData oExcelcon = new readExcelData();

/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
String FileName="UnityTestData.xlsx";
String SheetName="UsersPage";*/

@Test(priority=1)
public void DeleteUsers() throws Exception 
{
	
	test=report.createTest("TC# 4 :: DeleteUser"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[8]);
	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='email']"))));
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(8, 1, 0));
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='password']"))));
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(8, 1, 1));
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='submit']"))));
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	/*Thread.sleep(1000);
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']"))));
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
	*/

	 Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Users')]")).click();
	/*wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@ng-click=\"addingnewuser()\"]"))));
	obrw.findElement(By.xpath("//a[@ng-click=\"addingnewuser()\"]")).click();*/
	
	/*wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//*[@id=\"addUser\"]/div/div/div[2]/form/div[4]/div/div/div[1]/div/div[2]/div/select"))));
    obrw.findElement(By.xpath("//*[@id=\"addUser\"]/div/div/div[2]/form/div[4]/div/div/div[1]/div/div[2]/div/select")).click();*/
jswait.waitforAngular(obrw);


List<WebElement> sCellValue = obrw.findElements(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tbody//tr[1]//td[3]"));
sCellValue.size();

int size = sCellValue.size();
System.out.println(size);
	/*String sCellValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr[1]/td[1]")).getText();
	System.out.println(sCellValue);*/
	
	
	//First loop will find the 'Request ID' in the first column
	/*for (int i=1;i<=size;i++){
		String sValue = null;
		sValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody["+ i +"]/tr/td[3]")).getText();
		String sRowValue = nec.GetData(8, 1, 3);
		if(sValue.equalsIgnoreCase(sRowValue)){*/


			//List<WebElement> allrows = obrw.findElements(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr"));
            
			List<WebElement> allpages = obrw.findElements(By.xpath("//div[@ng-show='userstotal > itemsPerPage']//a "));
			    System.out.println("Total pages :" +allpages.size());
			    for(int i=0; i<=(allpages.size()); i++)
			    	  
			        {
			    	Boolean match=false;
			    	List<WebElement> allrows = obrw.findElements(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr/td[3]"));
			            for(int row=1; row<=allrows.size(); row++)
			                {
			                    System.out.println("Total rows :" +allrows.size()); 
			                    String name = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody["+ row +"]/tr/td[3]")).getText();
			                    //System.out.println(name);
			                    //System.out.println("Row loop");
			                    String sRowValue = nec.GetData(8, 1, 3);
			                    //Boolean match;
			                    if(name.equalsIgnoreCase(sRowValue))
			                    //if(name.contains("xxxx"))
			                        {
			                            WebElement Deletebutton = obrw.findElement(By.xpath("//table[@class='table table-link rwd-table']//tbody["+ row +"]//tr//td[5]//button[2]"));
			                            Deletebutton.click();
			                            Thread.sleep(1000);
			                            obrw.findElement(By.xpath("//button[contains(text(),'Yes')]")).click();
			                            match=true;
			                        	break;
			                        }
			                    else 
			                    {
			                        System.out.println("Element doesn't exist");
			                    }
			                    continue;
			                    //allpages = obrw.findElements(By.xpath("//div[@ng-show='userstotal > itemsPerPage']//a"));
			                }
			           
			            allpages = obrw.findElements(By.xpath("//div[@ng-show='userstotal > itemsPerPage']//a[text()='Next']"));
			            obrw.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
			           
			            if(match)
			        	{
			        	
			        		break;
			        	}
			            Boolean Same=fun.isElementPresent(obrw,By.xpath("//ul[@class='pull-right ng-untouched ng-valid ng-isolate-scope pagination ng-not-empty ng-dirty ng-valid-parse']//li[@class='pagination-next ng-scope disabled']"));
			            if(Same)
			        	{
			        	test.fail("no match found");
			        		break;
			        	}
			        	
			        	
			            allpages.get(i).click();
			            
			        }
                Thread.sleep(1000);
            	jswait.waitforAngular(obrw);
            	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
            	jswait.waitforAngular(obrw);
            	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
            	obrw.close();



		}
	
}

	

   
   
	
	
	




	




 

		





	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
