package unityscripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class ManageInstances  extends BaseExtentReport{

	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
ObjInfo oInfo=new ObjInfo();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
@Test
public void ManageInstance() throws Exception
{
	
	test=report.createTest("TC# 10 :: ManageInstance"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[7]);
	
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='email']"))));
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(7, 1, 0));
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='password']"))));
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(7, 1, 1));
	wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//input[@type='submit']"))));
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	jswait.waitforAngular(obrw);
	
    Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//a[contains(text(),'Operations')]")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[@ng-model='searchToggleIaas']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@placeholder='Enter Instance']")).sendKeys(nec.GetData(7, 1, 2));
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//select[@ng-model='FilterSearchIaas.Type']")).click();
	Select Location=new Select(obrw.findElement(By.xpath("//select[@ng-model='FilterSearchIaas.Type']")));
	Location.selectByVisibleText(nec.GetData(7, 1, 3));
	
	 Thread.sleep(1000);
	obrw.findElement(By.xpath("//button[@ng-click='applyFilterIaas(FilterSearchIaas)']")).click();
	 Thread.sleep(1000);
	
	Boolean NoData=fun.isElementPresent(obrw,By.xpath("//td[contains(text(),'No Data Found.')]"));	
		if( NoData)
		
		{	
			test.pass("No Data Found");
			
		}
		else
		{

			Thread.sleep(1000);
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tbody//tr[1]/td[5]")).click();
			jswait.waitforAngular(obrw);
			String success = obrw.findElement(By.xpath("//div[@id='startstop-success-modal']//div[@class='col-sm-12']")).getText();
			Thread.sleep(1000);
			test.pass(success);
			Thread.sleep(1000);
			obrw.findElement(By.xpath("//div[@id='startstop-success-modal']//button[@type='button']")).click();
			Thread.sleep(1000);
			String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
			Thread.sleep(1000);
			test.pass(log);
		
		}

	 Thread.sleep(1000);
	 	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
	 	Thread.sleep(1000);
	 	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
	 	obrw.close();
	
	}
}
