package unityscripts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class DashboardOnpremiseUsage  extends BaseExtentReport{
	
	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular waitall =new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();
waitforangular jswait = new waitforangular();
//BasePage chr = new BasePage();
//readExcelData oExcelcon = new readExcelData();

/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
String FileName="UnityTestData.xlsx";
String SheetName="UsersPage";*/

@Test(priority=1)
public void Usage() throws Exception 
{
	
	test=report.createTest("TC# 6 :: OnpremiseUsage"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	obrw.get(oInfo.URL);
	
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[12]);
	
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	

	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Email)).sendKeys(nec.GetData(12, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Password)).sendKeys(nec.GetData(12, 1, 1));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Submit)).click();
	Thread.sleep(1000);
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}

	 //Thread.sleep(1000);
	 jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//a[contains(text(),'On Premise')]")).click();
	Thread.sleep(1000);
	//Total Usage in Dashboard
	String Total = obrw.findElement(By.xpath("//div[@class='col-md-6 cto_usage']//section[@class='tab-pane fade collapseContainer active in']//div[1]//div[1]//div[1]")).getText();
    int Totalcount = Integer.parseInt(Total.replaceAll("\\D", ""));
    System.out.println("Total Count -------->"+Totalcount);
    //Allocate Usage in Dashboard
    String Allocate = obrw.findElement(By.xpath("//div[@class='col-md-6 cto_usage']//section[@class='tab-pane fade collapseContainer active in']//div[1]//div[2]//div[1]")).getText();
    int Allocatecount = Integer.parseInt(Allocate.replaceAll("\\D", ""));
    System.out.println("Allocated count ------------>"+Allocatecount);
    //Pool Usage in Dashboard
    String Pool = obrw.findElement(By.xpath("//div[@class='col-md-6 cto_usage']//section[@class='tab-pane fade collapseContainer active in']//div[1]//div[3]//div[1]")).getText();
    int Poolcount = Integer.parseInt(Pool.replaceAll("\\D", ""));
    System.out.println("Pool count ------------>"+Poolcount);
    Thread.sleep(1000);
    obrw.findElement(By.xpath("//a[contains(text(),'Manage')]")).click();
    Thread.sleep(1000);
    
    obrw.findElement(By.xpath("//a[contains(text(),'Instances')]")).click();
    obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@id='instances-filter']")).click();
    Thread.sleep(1000);
    Select InstStatus=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='Type']")));
    InstStatus.selectByVisibleText("OnPremise");           
    Thread.sleep(1000);
    obrw.findElement(By.xpath("//button[@ng-click='applyFilterIaas(FilterSearchIaas)']")).click();
    Thread.sleep(1000);
    
    int totalinstances=0;
    Boolean Totalin=fun.isElementPresent(obrw,By.xpath("//div[@ng-if='totalIAASInstances > 0']//b"));	
	if( Totalin)
	
	{	
   
    String Instances=obrw.findElement(By.xpath("//div[@ng-if='totalIAASInstances > 0']//b")).getText();
    int inatances = Integer.parseInt(Instances.replaceAll("\\D", ""));
    System.out.println("insatnces -->"+inatances);
    totalinstances=totalinstances+inatances;
	}
    obrw.findElement(By.xpath("//a[contains(text(),'Services')]")).click();
    Thread.sleep(1000);
    
    obrw.findElement(By.xpath("//a[contains(text(),'Services')]")).click();
    obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@id='instances-filter']")).click();
    Thread.sleep(1000);
    Select ServicestotalType=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='Type']")));
    ServicestotalType.selectByVisibleText("OnPremise");           
    Thread.sleep(1000);
    obrw.findElement(By.xpath("//button[@ng-click='applyFilterPaas(FilterSearch)']")).click();
    Thread.sleep(1000);
    
    Boolean Totalservices=fun.isElementPresent(obrw,By.xpath("//div[@ng-if='totalPAASInstances > 0']//b"));
	if( Totalservices)
	{
    String Instances=obrw.findElement(By.xpath("//div[@ng-if='totalPAASInstances > 0']//b")).getText();
    int services = Integer.parseInt(Instances.replaceAll("\\D", ""));
    System.out.println("service -->"+services);
    totalinstances=totalinstances+services;
	}
    
	System.out.println("total no of instances   --->"+totalinstances);
	
	if(Totalcount==totalinstances)
	{	
	 test.pass("Total count matched");
	 }
	else {
	  test.fail("Total count notmatched");
	    }
	
	//On premise Allocated count
	obrw.findElement(By.xpath("//a[contains(text(),'Instances')]")).click();
    obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@id='instances-filter']")).click();
    Thread.sleep(1000);
    Select ServicesStatus=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='type']")));
    ServicesStatus.selectByVisibleText("Allocated");
    Thread.sleep(1000);
    Select AllocInstStatus=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='Type']")));
    AllocInstStatus.selectByVisibleText("OnPremise");           
    Thread.sleep(1000);
    obrw.findElement(By.xpath("//button[@ng-click='applyFilterIaas(FilterSearchIaas)']")).click();
    Thread.sleep(1000);
    
    int TotalAllocInst=0;
    Boolean AllocInst=fun.isElementPresent(obrw,By.xpath("//div[@ng-if='totalIAASInstances > 0']//b"));	
    	if( AllocInst)
    	{	
    	String AllocInstances=obrw.findElement(By.xpath("//div[@ng-if='totalIAASInstances > 0']//b")).getText();
    	int TotalAllocatedinst = Integer.parseInt(AllocInstances.replaceAll("\\D", ""));	    
        Thread.sleep(1000);
        System.out.println("insatnces -->"+TotalAllocatedinst);
        TotalAllocInst=TotalAllocInst+TotalAllocatedinst;
    	}
    	  obrw.findElement(By.xpath("//a[contains(text(),'Services')]")).click();
    	    obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@id='instances-filter']")).click();
    	    Thread.sleep(1000);
    	    Select InstanceStatus=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='type']")));
    	    InstanceStatus.selectByVisibleText("Allocated");
    	    Thread.sleep(1000);
    	    Select ServicesCloudtype=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='Type']")));
    	    ServicesCloudtype.selectByVisibleText("OnPremise");
    	    Thread.sleep(1000);
    	    obrw.findElement(By.xpath("//button[@ng-click='applyFilterPaas(FilterSearch)']")).click();
    	    Thread.sleep(1000);
        Boolean TotalAllocservices=fun.isElementPresent(obrw,By.xpath("//div[@ng-if='totalPAASInstances > 0']//b"));
    	
    	if( TotalAllocservices)
    	
    	{
    
         String AllocServices=obrw.findElement(By.xpath("//div[@ng-if='totalPAASInstances > 0']//b")).getText();
    	 int TotalAllocServices = Integer.parseInt(AllocServices.replaceAll("\\D", ""));
        System.out.println("service -->"+TotalAllocServices);
        TotalAllocInst=TotalAllocInst+TotalAllocServices;
    	}
        
    	System.out.println("total no of instances   --->"+TotalAllocInst);
        Thread.sleep(1000);
        if(Allocatecount==TotalAllocInst)
        {
        	test.pass("Total Allocatedcount matched");
        }
        else {
        	    	 
        	 test.fail("Total Allocatedcount notmatched");
        }
      //Pool instances
        obrw.findElement(By.xpath("//a[contains(text(),'Instances')]")).click();
        obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@id='instances-filter']")).click();
        Thread.sleep(1000);
        Select InstPoolStatus=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='type']")));
        InstPoolStatus.selectByVisibleText("Pool");
        Thread.sleep(1000);
	    Select InstPoolCloudtype=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='Type']")));
	    InstPoolCloudtype.selectByVisibleText("OnPremise");
        obrw.findElement(By.xpath("//button[@ng-click='applyFilterIaas(FilterSearchIaas)']")).click();
        Thread.sleep(1000);
       
        int TotalpoolInst=0;
        Boolean poolInst=fun.isElementPresent(obrw,By.xpath("//div[@ng-if='totalIAASInstances > 0']//b"));	
        	if( poolInst)
        	
        	{	
           
        		   String poolInstances=obrw.findElement(By.xpath("//div[@ng-if='totalIAASInstances > 0']//b")).getText();
        		    int TotalPoolinst = Integer.parseInt(poolInstances.replaceAll("\\D", ""));
        		    
        		    Thread.sleep(1000);
            System.out.println("insatnces -->"+TotalPoolinst);
            TotalpoolInst=TotalpoolInst+TotalPoolinst;
        	}
        	  obrw.findElement(By.xpath("//a[contains(text(),'Services')]")).click();
        	    obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@id='instances-filter']")).click();
        	    Thread.sleep(1000);
        	    Select PoolServicesStatus=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='type']")));
        	    PoolServicesStatus.selectByVisibleText("Pool");
        	    Thread.sleep(1000);
        	    Select ServicesPoolCloudtype=new Select(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//select[@name='Type']")));
        	    ServicesPoolCloudtype.selectByVisibleText("OnPremise");
        	    obrw.findElement(By.xpath("//button[@ng-click='applyFilterPaas(FilterSearch)']")).click();
        	    Thread.sleep(1000);
            Boolean Totalpoolservices=fun.isElementPresent(obrw,By.xpath("//div[@ng-if='totalPAASInstances > 0']//b"));
        	
        	if( Totalpoolservices)
        	
        	{
        
             String poolServices=obrw.findElement(By.xpath("//div[@ng-if='totalPAASInstances > 0']//b")).getText();
        	 int TotalpoolServices = Integer.parseInt(poolServices.replaceAll("\\D", ""));
            System.out.println("service -->"+TotalpoolServices);
            TotalpoolInst=TotalpoolInst+TotalpoolServices;
        	}
            
        	System.out.println("total no of instances   --->"+TotalpoolInst);
            Thread.sleep(1000);
            if(Poolcount==TotalpoolInst)
            {
            	test.pass("Total poolcount matched");
            }
            else {
            	    	 
            	 test.fail("Total Poolcount notmatched");
            }
    
   
    Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
	obrw.close();
	}
	}

