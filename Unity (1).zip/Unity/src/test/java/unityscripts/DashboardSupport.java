package unityscripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class DashboardSupport extends BaseExtentReport{
	
	WebDriver obrw;
	NewExcelConfig nec=new NewExcelConfig();
	waitforangular waitall =new waitforangular();
	functionLibs fun = new functionLibs();
	ObjInfo oInfo=new ObjInfo();
	waitforangular jswait = new waitforangular();
	//BasePage chr = new BasePage();
	//readExcelData oExcelcon = new readExcelData();

	/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
	String FileName="UnityTestData.xlsx";
	String SheetName="UsersPage";*/

	@Test(priority=1)
	public void Dashboard() throws Exception 
	{
		
		test=report.createTest("TC# 8 :: Support"); 
		System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
		obrw=new ChromeDriver();
		obrw.manage().window().maximize();
		//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
		obrw.get(oInfo.URL);
		
		//WebDriverWait wait=new WebDriverWait(obrw, 100);
		nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[12]);
		
		//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
		obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
		

		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath(oInfo.Email)).sendKeys(nec.GetData(12, 1, 0));
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath(oInfo.Password)).sendKeys(nec.GetData(12, 1, 1));
		obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obrw.findElement(By.xpath(oInfo.Submit)).click();
		Thread.sleep(1000);
	Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
		
		if( selectedou)
		
		{
		obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
				
		}
		
		for(int i=1;i<=2;i++)
	    	 
	     {

		 Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[contains(text(),'Hybrid')]")).click();
		Thread.sleep(1000);
		//Total Usage in Dashboard
		String New = obrw.findElement(By.xpath("//div[@class='col-md-6 cto_support']//div[1]//div[1]//div[1]//div[1]")).getText();
	    int dashboardNewcount = Integer.parseInt(New.replaceAll("\\D", ""));
	    System.out.println(dashboardNewcount);
	    //Allocate Usage in Dashboard
	    String Inprogress = obrw.findElement(By.xpath("//div[@class='col-md-6 cto_support']//div[1]//div[1]//div[2]//div[1]")).getText();
	    int dashboardInprogresscount = Integer.parseInt(Inprogress.replaceAll("\\D", ""));
	    System.out.println(dashboardInprogresscount);
	    //Pool Usage in Dashboard
	    String Closed = obrw.findElement(By.xpath("//div[@class='col-md-6 cto_support']//div[1]//div[1]//div[3]//div[1]")).getText();
	    int DashboardClosedcount = Integer.parseInt(Closed.replaceAll("\\D", ""));
	    System.out.println(DashboardClosedcount);
	    String Cancelled = obrw.findElement(By.xpath("//div[@class='col-md-6 cto_support']//div[1]//div[1]//div[4]//div[1]")).getText();
	    int DashboardCancelledcount = Integer.parseInt(Cancelled.replaceAll("\\D", ""));
	    System.out.println(DashboardCancelledcount);
	    Thread.sleep(1000);
	    waitall.waitforAngular(obrw);
	    
	    obrw.findElement(By.xpath("//a[@class='navbar-brand']")).click();
	    obrw.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	    //obrw.findElement(By.xpath("//a[contains(text(),'Support')]")).click();
	    obrw.findElement(By.xpath("//div[1]/a[contains(text(),'Support')]")).click();
	    waitall.waitforAngular(obrw);
	    
	    Thread.sleep(1000);
	       String supportNew = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope']")).getText();
	       int supportnewcount = Integer.parseInt(supportNew.replaceAll("\\D", ""));
	       System.out.println(supportnewcount);
	       //In Progress
	       String supportInprogress = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope countprogress']")).getText();	       
	       int supportInprogresscount = Integer.parseInt(supportInprogress.replaceAll("\\D", ""));
	       System.out.println(supportInprogresscount);
	       Thread.sleep(1000);
	     //Closed
	       String supportClosed = obrw.findElement(By.xpath("//div[@class='col-sm-3 countnew ng-scope countclosed']")).getText();	       
	       int supportClosedcount = Integer.parseInt(supportClosed.replaceAll("\\D", ""));
	       System.out.println(supportClosedcount);
	       Thread.sleep(1000);
	     //Cancelled
	       String supportCancelled = obrw.findElement(By.xpath("//div[@class='col-sm-12 countcards text-center']//div[4]")).getText();	       
	       int supportCancelledcount = Integer.parseInt(supportCancelled.replaceAll("\\D", ""));
	       System.out.println(supportCancelledcount);
	       
	       if(dashboardNewcount==supportnewcount)
	       {
	       	test.pass("New count matched");
	       }
	       else {
	       	    	 
	       	 test.fail("New count notmatched");
	       }
	       if(dashboardInprogresscount==supportInprogresscount)
	       {
	       	test.pass("Inprogress count matched");
	       }
	       else {
	       	    	 
	       	 test.fail("Inprogress count notmatched");
	       }
	       if(DashboardClosedcount==supportClosedcount)
	       {
	       	test.pass("Closed count matched");
	       }
	       else {
	       	    	 
	       	 test.fail("closed count notmatched");
	       }
	       if(DashboardCancelledcount==supportCancelledcount)
	       {
	       	test.pass("Cancelled count matched");
	       }
	       else {
	       	    	 
	       	test.fail("Cancelled count notmatched");
	       }
	       Thread.sleep(1000);
	       obrw.findElement(By.xpath("//a[@class='navbar-brand']")).click();
	     }
	       
	       Thread.sleep(1000);
	    	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
	    	Thread.sleep(1000);
	    	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
	    	obrw.close();
	       
	       
	    
	

}
}
