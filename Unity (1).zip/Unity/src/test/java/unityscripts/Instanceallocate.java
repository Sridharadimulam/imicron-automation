package unityscripts;


import static org.testng.Assert.assertFalse;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class Instanceallocate  extends BaseExtentReport{
	
	
WebDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
ObjInfo oInfo=new ObjInfo();
//BasePage chr = new BasePage();
//readExcelData oExcelcon = new readExcelData();

/*String ExcelPath="C:\\Users\\10504\\eclipse-workspace\\unity\\src\\test\\java\\TestData\\";
String FileName="UnityTestData.xlsx";
String SheetName="UsersPage";*/

@Test(priority=1)
public void Instance() throws Exception 
{
	
	test=report.createTest("TC# 2 :: Instanceallocate"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	//obrw.get("http://www.imicrondev.com/Automation/Enterprise/Portal");
	obrw.get(oInfo.URL);
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[14]);
	
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Email)).sendKeys(nec.GetData(14, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Password)).sendKeys(nec.GetData(14, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath(oInfo.Submit)).click();
	Thread.sleep(1000);
	JavascriptExecutor js = (JavascriptExecutor) obrw;  
	js.executeScript("window.open()");
//	((JavascriptExecutor)obrw).executeScript("window.open()");
	ArrayList<String> tabs = new ArrayList<String>(obrw.getWindowHandles());
	obrw.switchTo().window(tabs.get(1));
	obrw.get("http://www.imicrondev.com/QA/Enterprise/Portal/Home/configuration");
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[@ng-click='next(organization, 1)']")).click();
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[@ng-click='next(organization, 2)']")).click();
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[@ng-click='next(organization, 3)']")).click();
	
	/*List<WebElement> sCellValue = obrw.findElements(By.xpath("//div[@id='instances']//tbody//tr//td[1]"));
	sCellValue.size();

	int size = sCellValue.size();
	System.out.println(size);*/
	 int iRows=nec.rowCount(14);

     System.out.println(iRows);
     for(int j=1;j<=iRows;j++)
    	 
     {
	
	
	List<WebElement> allpages = obrw.findElements(By.xpath("//td[@ng-show='totalPAASInstances > itemsPerPage']//a "));
    System.out.println("Total pages :" +allpages.size());
    for(int i=0; i<=(allpages.size()); i++)
    	
        {
    	Boolean match=false;
    	Thread.sleep(1000);
    	String Instance = nec.GetData(14, 1, 2);
    	System.out.println(Instance);
    	obrw.findElement(By.xpath("//a[contains(text(),'"+ Instance +"')]")).click();
    	List<WebElement> allrows = obrw.findElements(By.xpath("//div[@id='services']//div//tbody//tr//td[1]"));
            for(int row=1; row<=allrows.size(); row++)
                {
                    System.out.println("Total rows :" +allrows.size()); 
                    
                	Thread.sleep(1000);
                    String Instname = obrw.findElement(By.xpath("//div[@id='services']//div//tbody//tr["+ row +"]//td[1]")).getText();
                    String Ouname = obrw.findElement(By.xpath("//div[@id='services']//div//tbody//tr["+ row +"]//td[2]")).getText();
                   
                    //System.out.println(name);
                    //System.out.println("Row loop");
                    String sRowValue = nec.GetData(14, j, 3);
                    String Ou = nec.GetData(14, j, 4);
                    if(Instname.equalsIgnoreCase(sRowValue))
                    //if(name.contains("xxxx"))
                        {
                    	if(Ouname.equalsIgnoreCase(Ou))
                           
                        	    
                    	obrw.findElement(By.xpath("//div[@id='services']//div//tbody//tr["+ row +"]//td[4]//button[1]")).click();
                    	Thread.sleep(1000);
                    	obrw.findElement(By.xpath("//span[@class='select2-arrow ui-select-toggle']")).click();
                    	
                    	Thread.sleep(1000);
                    	obrw.findElement(By.xpath("//input[@type='search']")).sendKeys(nec.GetData(14, j, 5));
                    	
                    	WebElement textbox = obrw.findElement(By.xpath("//input[@type='search']"));
                    	textbox.sendKeys(Keys.ENTER);
                    	Thread.sleep(1000);
                    	obrw.findElement(By.xpath("//input[@placeholder='Start Date']")).clear();
                    	obrw.findElement(By.xpath("//input[@placeholder='Start Date']")).sendKeys(nec.GetData(14, j, 6));
                    	Thread.sleep(1000);
                    	obrw.findElement(By.xpath("//input[@placeholder='End Date']")).clear();
                    	obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(14, j, 7));
                    	
                    	obrw.findElement(By.xpath("//button[@id='transfer-confirm']")).click();
                    	Thread.sleep(1000);
                    	obrw.findElement(By.xpath("//div[@id='transfer-modal']//button[@type='button']")).click();
                    	/*obrw.navigate().refresh();
                    	Thread.sleep(1000);
                    	obrw.findElement(By.xpath("//a[@ng-click='next(organization, 1)']")).click();
                    	Thread.sleep(1000);
                    	obrw.findElement(By.xpath("//a[@ng-click='next(organization, 2)']")).click();
                    	Thread.sleep(1000);
                    	obrw.findElement(By.xpath("//a[@ng-click='next(organization, 3)']")).click();*/
                    	
                            match=true;
                        	break;
                        }
                    else 
                    {
                        System.out.println("Element doesn't exist");
                    }
                    continue;
                    //allpages = obrw.findElements(By.xpath("//div[@ng-show='userstotal > itemsPerPage']//a"));
                }

            WebElement allpages1 =  obrw.findElement(By.xpath("//td[@ng-show='totalPAASInstances > itemsPerPage']//a[text()='Next'] "));
            obrw.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
           
            if(match)
        	{
        	
        		break;
        	}
            Boolean notmatch=fun.isElementPresent(obrw,By.xpath("//ul[@class='pull-right ng-untouched ng-valid ng-isolate-scope pagination ng-not-empty ng-dirty ng-valid-parse']//li[@class='pagination-next ng-scope disabled']"));
           
            if(notmatch)
        	{
            	
        	     test.fail("no match found");
        
        	}
            
           allpages1.click();
          
            
        }
     }
     Thread.sleep(1000);
 	jswait.waitforAngular(obrw);
 	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
 	jswait.waitforAngular(obrw);
 	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
 	obrw.close();
}
}