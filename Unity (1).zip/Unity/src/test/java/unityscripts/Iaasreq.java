package unityscripts;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import FunctionalData.BaseExtentReport;
import FunctionalData.NewExcelConfig;
import FunctionalData.functionLibs;
import FunctionalData.waitforangular;
import ObjRepo.ObjInfo;

public class Iaasreq extends BaseExtentReport{

	
ChromeDriver obrw;
NewExcelConfig nec=new NewExcelConfig();
ObjInfo oInfo=new ObjInfo();
waitforangular jswait = new waitforangular();
functionLibs fun = new functionLibs();
@Test
public void Request() throws Exception
{
	//JSWaiter.setDriver(obrw);
	test=report.createTest("TC# 11 :: Iaasreq"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[9]);
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(9, 1, 0));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(9, 1, 1));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	jswait.waitforAngular(obrw);
	
Boolean selectedou=fun.isElementPresent(obrw,By.xpath("//a[@ng-click='proceed(selectedOU)']"));
	
	if( selectedou)
	
	{
	obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
			
	}
	
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//div[@class='col-sm-3 requests']//div[@class='col-sm-2 icon']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//a[@ng-click='newRequest()']")).click();
	//Thread.sleep(1000);
	
	String Request = nec.GetData(9, 1, 2);
	String Questionarie1 =nec.GetData(9,1,3);
	String Questionarie2 =nec.GetData(9,1,4);

	jswait.waitforAngular(obrw);
	
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//div[@class='col-sm-10']//div[@class='title'][b[text()='"+ Request +"']]/following-sibling::a")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//span[text()='" + Questionarie1 + "']")).click();
	//assertFalse(obrw.findElement(By.xpath("//div[@ng-show='computeserviceform.days.$error.required && error']")).isDisplayed(),"Please Select any one option");
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//span[text()='" + Questionarie2 + "']")).click();
	//assertFalse(obrw.findElement(By.xpath("//div[@ng-show='computeserviceform.months.$error.required && error']")).isDisplayed(),"Please Select any one option");
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//button[text()='NEXT']")).click();
	
obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
String size = nec.GetData(9, 1, 5);
String OS = nec.GetData(9, 1, 6);
String Cloud = nec.GetData(9, 1, 7);
//System.out.println(size);
obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ size +"']")).click();
obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ OS +"']")).click();
obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
obrw.findElement(By.xpath("//label[@class='radio-inline ng-binding ng-scope "+ Cloud +"']")).click();
obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
obrw.findElement(By.xpath("//button[text()='SUBMIT']")).click();
jswait.waitforAngular(obrw);
//String Request1 = obrw.findElement(By.xpath("//p[text()='Your request  has been created successfully with id \"']")).getText();


// Alert alert = obrw.switchTo().alert();
//System.out.println(alert.getText());
//alert.accept();
String Request1 = obrw.findElement(By.xpath("//div[@class='col-sm-12']//p[@class='ng-binding']")).getText();
//System.out.println(Request1);
test.pass(Request1);

//if(Request1.startsWith("UN"))
String requestid;
String strarray[] =Request1.split(" ");

for(String str:strarray) {
if (str.contains("UN")) {
	
	str = str.replaceAll("^\"|\"$",""); 
	requestid=str;
	nec.setCellData(9, 1, 8, requestid);	
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//div[@class='row']//button[@type='button'][contains(text(),'Ok')]")).click();
	
	jswait.waitforAngular(obrw);
 	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
 	jswait.waitforAngular(obrw);
 	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
 	obrw.close();
}
}
}

@Test(dependsOnMethods = { "Request" })
public void Authorize() throws Exception
{
	
	test=report.createTest("TC# 11.2 :: Authorize"); 
	System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	obrw=new ChromeDriver();
	obrw.manage().window().maximize();
	obrw.get(oInfo.URL);
	//WebDriverWait wait=new WebDriverWait(obrw, 100);
	nec.readExcel(oInfo.ExcelPath,oInfo.ExcelFile,oInfo.SheetName[9]);
	//waitall.waitforAngular(obrw);
	
	//waitall.waitforPageLoad(obrw);
	
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//a[@href=\"/QA/Enterprise/Portal/Home/Signin\"]"))));
	obrw.findElement(By.xpath("//a[text()='Get Started']")).click();
	
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='email']")).sendKeys(nec.GetData(9, 1, 9));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='password']")).sendKeys(nec.GetData(9, 1, 10));
	obrw.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	obrw.findElement(By.xpath("//input[@type='submit']")).click();
	//jswait.waitforAngular(obrw);
	//JSWaiter.sleep(1000);
	//obrw.findElement(By.xpath("//a[@ng-click='proceed(selectedOU)']")).click();
	
	obrw.findElement(By.xpath("//div[@class='col-sm-3 requests']//div[@class='col-sm-2 icon']")).click();
	Thread.sleep(1000);
	obrw.findElement(By.xpath("//a[contains(text(),'Authorize Requests')]")).click();
	jswait.waitforAngular(obrw);
	List<WebElement> sCellValue = obrw.findElements(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr/td[1]"));
	 sCellValue.size();
	 
	 int size = sCellValue.size();
	/*String sCellValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//table/tbody/tr[1]/td[1]")).getText();
	System.out.println(sCellValue);*/
	String sRowValue = nec.GetData(9, 1, 8);
	
	//First loop will find the 'Request ID' in the first column
	for (int i=1;i<=size;i++){
		String sValue = null;
		sValue = obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[1]")).getText();
		if(sValue.equalsIgnoreCase(sRowValue)){
			
			obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[8]/span[2]")).click();
	/*obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[" + i + "]/td[1]")).click();
	
	obrw.findElement(By.xpath("//span[@class='ng-binding'][contains(text(),'Authorize')]")).click();*/
	
		break;	
		}	
	}
	
	//Same Configuration
	obrw.findElement(By.xpath("//a[contains(text(),'Same Configuration')]")).click();
    Boolean Same=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']"));
	
	if( Same)
	   
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']")).isDisplayed())
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).isDisplayed())
	{
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).click();
		
		obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(9, 1, 11));
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//button[text()='Allocate']")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[1]/td[1]")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[@ng-click='getInstanceDetails(ticketinfo)']")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[contains(text(),'Request History')]")).click();
		
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).click();
		
		String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
		Thread.sleep(1000);
		test.pass(log);
	}
	Boolean Nodata=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//td[text()='No Data Found']"));
	if(Nodata) 
		{
	obrw.findElement(By.xpath("//a[contains(text(),'Similar Configuration')]")).click();
	Thread.sleep(1000);
Boolean Similar=fun.isElementPresent(obrw,By.xpath("//section[@class='tab-pane fade collapseContainer active in']//tr[@ng-click='selectRequest(similarmatch) || reservedDetails(similarmatch)']"));
	
	if( Similar)
	   
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//thead//tr[@ng-click='selectRequest(exactmatch) || reservedDetails(exactmatch)']")).isDisplayed())
	//if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).isDisplayed())
	{
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//div[@class='col-md-12']//thead//tr[2]")).click();
		
        obrw.findElement(By.xpath("//input[@placeholder='End Date']")).sendKeys(nec.GetData(9, 1, 11));
		
		obrw.findElement(By.xpath("//button[text()='Allocate']")).click();
		Thread.sleep(2000);
		obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']/table/tbody/tr[1]/td[1]")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[@ng-click='getInstanceDetails(ticketinfo)']")).click();
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//a[contains(text(),'Request History')]")).click();
		
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//tbody//tr[1]//td[1]")).click();
		
		String log = obrw.findElement(By.xpath("//ul[@class='list']//li[1]")).getText();
		Thread.sleep(1000);
		test.pass(log);

	}
	
	else if(obrw.findElement(By.xpath("//section[@class='tab-pane fade collapseContainer active in']//td[text()='No Data Found']")).isDisplayed())
	{
		obrw.findElement(By.xpath("//button[contains(text(),'Procure new Instance')]")).click();
		Thread.sleep(1000);
		Boolean procure=fun.isElementPresent(obrw,By.xpath("//div[@class='modal-body ng-pristine ng-untouched ng-valid ng-not-empty']//div[1]"));
		
		if( procure)
		{
			obrw.findElement(By.xpath("//button[text()='OK']")).click();
		}
		else
		{
		obrw.findElement(By.xpath("//input[@name='Title']")).sendKeys(nec.GetData(9, 1, 12));
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//textarea[@name='Description']")).sendKeys(nec.GetData(9, 1, 13));
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//button[contains(text(),'Add')]")).click();
		

		obrw.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		jswait.waitforAngular(obrw);
		String Ticket = obrw.findElement(By.xpath("//div[@id='bpmTicketnumber-modal']//div[@class='modal-body']")).getText();
		System.out.println(Ticket);
		Thread.sleep(1000);
		test.pass(Ticket);
		Thread.sleep(1000);
		obrw.findElement(By.xpath("//div[@id='bpmTicketnumber-modal']//button[@type='button']")).click();
		}
	}
		}
Thread.sleep(1000);
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//a[@id='user-activity']")).click();
	jswait.waitforAngular(obrw);
	obrw.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
	obrw.close();
	
	}

	}
