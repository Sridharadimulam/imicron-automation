package com.qa.tms.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.tms.base.Testbase;

public class Loginpage extends Testbase {
	public static Logger log=Logger.getLogger(Loginpage.class);
	@FindBy(xpath="//*[@id='Tile6']")
	public static WebElement tilethebigwordtmstile;
	
	public Loginpage(){
		PageFactory.initElements(dr, this);
	}
	public void clickontilethebigwordtmstile(){
		System.out.println("hi");
		tilethebigwordtmstile.click();
	}
}
