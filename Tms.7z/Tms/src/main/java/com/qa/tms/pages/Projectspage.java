package com.qa.tms.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.tms.base.Testbase;

public class Projectspage extends Testbase{
	public static Logger log=Logger.getLogger(Projectspage.class);
	@FindBy(xpath="//*[@id='sidebar']/nav/ul/li[11]/a/span[2]")
	public static WebElement createproject;
	public Projectspage(){
		PageFactory.initElements(dr, this);
	}
	
	public void createproject() throws InterruptedException{
		createproject.click();
		
		log.info("createproject");
	}

}
