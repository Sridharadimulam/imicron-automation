package com.qa.tms.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.qa.tms.pages.Homepage;
import com.qa.tms.utils.ObjInfo;
import com.qa.tms.utils.Timeutils;

public class Testbase  {
	private static Logger log=Logger.getLogger(Testbase.class.getName());
	public static WebDriver dr;
	public static FileInputStream fi;
	public static Properties pr;
	public ExtentHtmlReporter htmlreporter;
	public ExtentReports reports;
	public ExtentTest test;
	public Homepage h;

	public Testbase t;
	 ObjInfo oInfo=new ObjInfo();
public Testbase(){
try{
	pr=new Properties();
fi=new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\com\\qa\\tms\\config\\config.properties");
pr.load(fi);
log.info("file load sucessfullay");

}
catch(FileNotFoundException fnf){
	fnf.printStackTrace();
}catch(IOException io){
	io.printStackTrace();
}
}
@BeforeTest
public void beforetest(){
	String log4jpath=System.getProperty("user.dir")+"\\src\\main\\java\\com\\qa\\tms\\resources\\log4J.properties";
	PropertyConfigurator.configure(log4jpath);

}
public  void initialization(){
String browsername=pr.getProperty("browser");

if(browsername.equals("chrome")){
	System.setProperty("webdriver.chrome.driver", "D:\\seleniumworkspace\\Tms\\Driver\\chromedriver.exe");
	dr=new ChromeDriver();
}else if(browsername.equals("firefox")){
	dr=new FirefoxDriver();
}
	dr.manage().window().maximize();
	dr.manage().deleteAllCookies();
	dr.manage().timeouts().pageLoadTimeout(Timeutils.PAGELOAD_TIME, TimeUnit.SECONDS);
	dr.manage().timeouts().implicitlyWait(Timeutils.IMPLICIT_WAIT, TimeUnit.SECONDS);
	dr.get(pr.getProperty("url"));
	}
@BeforeSuite
public void setup(){
	htmlreporter=new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/UnityReport.html");
reports=new ExtentReports();
reports.attachReporter(htmlreporter);

htmlreporter.config().setChartVisibilityOnOpen(true);
htmlreporter.config().setDocumentTitle("techwave");	
htmlreporter.config().setReportName("sridhar");
htmlreporter.config().setTheme(Theme.DARK);	
htmlreporter.config().setTestViewChartLocation(ChartLocation.TOP);
}


@AfterMethod
public void getResult(ITestResult result){
	if(result.getStatus()==ITestResult.SUCCESS){
		test.log(Status.PASS,MarkupHelper.createLabel(result.getName()+" Test Case PASSED", ExtentColor.GREEN));
	}
	 else
        {
            test.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" Test Case SKIPPED", ExtentColor.ORANGE));
            test.skip(result.getThrowable());
        }
                }

 @AfterSuite
    public void tearDown() throws Exception
    {
                                reports.flush();
                               dr.close();
                                System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
                                dr=new ChromeDriver();
                                dr.manage().window().maximize();
                                dr.get(System.getProperty("user.dir") +"/test-output/UnityReport.html");            
                                Thread.sleep(5000);
                                
    }
	
}








	


