package com.qa.tms.utils;

public class Timeutils {
public static long PAGELOAD_TIME=1000;
public static long IMPLICIT_WAIT=1000;
}
