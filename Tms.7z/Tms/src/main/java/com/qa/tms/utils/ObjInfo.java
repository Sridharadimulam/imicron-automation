package com.qa.tms.utils;

public class ObjInfo {
	public String ExcelPath=System.getProperty("user.dir") +"/src/test/java/TestData";			
	public String ExcelFile="UnityTestData.xlsx";
	public String DriverPath=System.getProperty("user.dir") +"\\Driver\\chromedriver.exe";
	public String URL ="https://uat-gms.thebigword.com";
	//public String URL ="http://unity.imicroncloud.com/techwave/Home/Signin";
	public String XMLPath =System.getProperty("user.dir") +"/src/test/resources/Unity.xml";
	public String HtmlPath=System.getProperty("user.dir") +"/test-output/UnityReport.html";				
	public String[] SheetName = new String[]{"TestScripts","WorkFlows","UsersPage", "Transfer", "Release", "SupportPage","Createtcket","ManageInstance","EditUser","IassRequest","PassRequest","CreateRequest","Usage","Requests","Instanceallocate","Transfer(L1)"};
	
	
	

	
}
