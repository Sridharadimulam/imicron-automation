package com.qa.tms.pages;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.tms.base.Testbase;

public class Homepage extends Testbase{
	public static Logger log=Logger.getLogger(Homepage.class);

@FindBy(xpath="/html//input[@id='Username']")
public static WebElement username;

@FindBy(xpath="//*[@id='Password']")
public static WebElement password;
@FindBy(xpath="//*[@id='loginButton']/span[2]")
public static WebElement login;
public Homepage(){
	PageFactory.initElements(dr,this);
}
public void login(){
	
	username.sendKeys(pr.getProperty("username"));
	password.sendKeys(pr.getProperty("password"));
	login.click();
	log.info("login sucess");
	
}


}
