package com.qa.tms.pages;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.tms.base.Testbase;

public class Companysearchpage extends Testbase{
	public static Logger log=Logger.getLogger(Companysearchpage.class);
@FindBy(xpath="//*[@id='buttonRefresh']")
public static WebElement search;
@FindBy(xpath="//*[@id='BillingAccountsGrid']/table/tbody/tr/td[1]/a[3]/span")
public static WebElement crateicon;


	public Companysearchpage(){
		PageFactory.initElements(dr, this);
	}
	
	public void search() throws InterruptedException{
		search.click();
		Thread.sleep(1000);
		crateicon.click();
	}
}
