package Excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelreadtest {
private String rownumber;
	public static void main(String[] args) throws IOException {
		File f=new File("D:\\seleniumworkspace\\Practice\\sh1.xlsx");
		FileInputStream fi=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fi);
		XSSFSheet sh=wb.getSheetAt(0);
		 System.out.println("no of sheets are:"+wb.getNumberOfSheets());
		 System.out.println(sh.getSheetName());
		int lastrow=sh.getLastRowNum();
		System.out.println(lastrow);
		int lastcell=sh.getRow(1).getLastCellNum();
		System.out.println(lastcell);

		for (int i=1; i<lastrow;i++){
			for(int j=0;j<lastcell;j++){
			String exe=sh.getRow(i).getCell(j).getStringCellValue();
			System.out.println(exe);
		
			if(exe.equalsIgnoreCase("Y")){
	String s=sh.getRow(i).getCell(2).getStringCellValue();
		//int result = Integer.parseInt(s);	
		System.out.println(s);
		String arrayvar[]=s.split(",");
		for(String eachvar:arrayvar){
			System.out.println(eachvar);
		
		}}
		}}
	}}
