package Excel;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class testexcel {

	public static void main(String[] args) throws IOException {
		File f=new File("D:\\seleniumworkspace\\Practice\\sh1.xlsx");
		FileInputStream fi=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fi);
		XSSFSheet sh=wb.getSheetAt(0);
		 //System.out.println("no of sheets are:"+wb.getNumberOfSheets());
		// System.out.println(sh.getSheetName());
		int lastrow=sh.getLastRowNum();
		System.out.println(lastrow);//3
		int lastcell=sh.getRow(1).getLastCellNum();
		System.out.println(lastcell);//4
		//String s=sh.getRow(1).getCell(3).getStringCellValue();
	for(int i=1;i<=lastrow;i++){
		for(int j=1;j<=lastcell-1;j++){
	/*String s=sh.getRow(i).getCell(j-1).getStringCellValue();
	System.out.println(s);*/
			String s=sh.getRow(i).getCell(3).getStringCellValue();
			//System.out.println(s);
	
	String s1=sh.getRow(i).getCell(0).getStringCellValue();
	String s2=sh.getRow(i).getCell(2).getStringCellValue();
	//System.out.println(s1);
if(s.equals("y")){
	//System.out.println(
	String arrayvar[]=s2.split(",");
	for(String eachvar:arrayvar){
		System.out.println(eachvar);	
	}
	}
	}
		
	

	}


}}