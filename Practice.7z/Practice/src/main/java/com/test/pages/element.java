package com.test.pages;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class element {

	public static void main(String[] args) {
WebDriver dr=new ChromeDriver();
dr.get("http://qa.thelittleword.com/ContactEdit.aspx?CompanyID=TST001&ContactID=303189");
dr.manage().window().maximize();
List<WebElement>l=dr.findElements(By.xpath("//*[@id='phContent_cmbLanguage']"));

//List<WebElement> options=dr.findElements(By.tagName("option"));
for (int i=0;i<=l.size();i++){
l.get(i).getText();
System.out.println(l.get(i).getText());
}


	}

}
