package com.test.helpers;

import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Dropdownhelper {
	public WebDriver dr;
	private Logger log=Logger.getLogger(Dropdownhelper.class);
	public Dropdownhelper(WebDriver dr){
		this.dr=dr;	
		log.debug("Dropdownhelper"+this.dr.hashCode());
	}
	
	public void selectusingvisiblvalue(WebElement element,String visibletext){
		Select se=new Select(element);
		se.selectByVisibleText(visibletext);
		log.info("locator:"+element+ "value:"+visibletext);
	}
	public String getselectedvalue(WebElement element){
		String value=new Select(element).getFirstSelectedOption().getText();
		log.info("Webelement"+element+"value:"+value);
		return value;
	}
	
	public void selectusingIndex(WebElement element,int index){
		Select se=new Select(element);
		se.selectByIndex(index);
		log.info("locator:"+element+ "value:"+index);
	}
	
	
	public List<String> getAlldropdownvalues(WebElement locator){
		Select se=new Select(locator);
		List<WebElement>elementlist=se.getAllSelectedOptions();
		List<String>valuelist=new LinkedList<String>();
		
		for(WebElement element:elementlist){
			log.info(element.getText());
			valuelist.add(element.getText());
		}
		return valuelist;
		
	}
}
