package com.test.helpers;

import org.openqa.selenium.WebElement;

public class verificationhelper {
public static synchronized boolean verifyElementPresent(WebElement element){
	//log.info("element  not displayed"+e)
	boolean isDisplayed=false;
	try{
		isDisplayed=element.isDisplayed();
element.getText();

	}catch(Exception e){
		//log.error("element  not found"+e)
	}return isDisplayed;
}

public static synchronized boolean verifyElementNOtPresent(WebElement element){
	boolean isDisplayed=false;
	try{
	element.isDisplayed();
	//log.info("element.getText()+"is displaye");
	element.getText();	
	}
	catch(Exception e){
		//log.error("element  not found"+e)
		isDisplayed=true;
	}return isDisplayed;
}
public static synchronized boolean verifytextEqual(WebElement element,String expectedtext){
	boolean flag=false;
	try{
		String actvaltext=element.getText();
		
		if(actvaltext.equals(expectedtext)){
			//log.info(actvaltext is"+actvalte+"expected text is "+expectedtext);
			return flag=true;
		}else{
			//log.error(actvaltext is"+actvalte+"expected text is "+expectedtext);
		}}
		catch(Exception e){
			//log.error(actvaltext is"+actvalte+"expected text is "+expectedtext);
			//log.info(""text is not matching"+e);
		}return flag;
	}
}


