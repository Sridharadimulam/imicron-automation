package com.test.helpers;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Waithelper {
	public WebDriver dr;
	private Logger log=Logger.getLogger(Waithelper.class);
	public Waithelper(WebDriver dr){
		this.dr=dr;		
		log.debug("Waithelper"+this.dr.hashCode());	
	}
	public void setimplicitwait(long timeout,TimeUnit unit){
		log.info(timeout);
		dr.manage().timeouts().implicitlyWait(timeout, unit==null ? TimeUnit.SECONDS:unit);
	}

public WebDriverWait getwait(long timeoutinmilliseconds,int pollingEveryInmilliseconds){
	log.debug("");
	WebDriverWait wait=new WebDriverWait(dr,timeoutinmilliseconds);
	wait.pollingEvery(pollingEveryInmilliseconds,TimeUnit.MILLISECONDS);
	wait.ignoring(NoSuchElementException.class);
	wait.ignoring(ElementNotVisibleException.class);
	wait.ignoring(StaleElementReferenceException.class);
	wait.ignoring(NoSuchFrameException.class);
	return wait;
}
public void waitforElementvisible(WebElement locator,long timeoutinmilliseconds,int pollingeveryinmilliseconds){
	log.info(locator);
	WebDriverWait wait=getwait(timeoutinmilliseconds, pollingeveryinmilliseconds);
	wait.until(ExpectedConditions.visibilityOf(locator));
}
public void waitforElement(WebDriver dr,WebElement element,long timeout){
	WebDriverWait wait=new WebDriverWait(dr, timeout);
	wait.until(ExpectedConditions.visibilityOf(element));
	log.info("element found"+element.getText());	
}
public WebElement waitforElement(WebDriver dr,long timeout,WebElement element){
	WebDriverWait wait=new WebDriverWait(dr, timeout);

	return 	wait.until(ExpectedConditions.elementToBeClickable(element));
}


}
