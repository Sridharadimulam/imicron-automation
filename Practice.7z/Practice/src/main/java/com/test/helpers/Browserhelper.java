package com.test.helpers;

import java.awt.Window;
import java.util.LinkedList;
import java.util.Set;

import org.openqa.selenium.WebDriver;

public class Browserhelper {
	public WebDriver dr;
	
	public Browserhelper(WebDriver dr){
		this.dr=dr;
	}

	public void goback(){
		dr.navigate().back();
	}
	public void gofarwad(){
		dr.navigate().forward();
	}
	public void Refresh(){
		dr.navigate().refresh();
	}
	
	public  Set<String> getwinowhandles(){
		return dr.getWindowHandles();	
	}
	public void switchtowindow(int index){
		LinkedList<String>windowid=new LinkedList<String>(getwinowhandles());
		if(index< 0|| index>windowid.size())
			throw new IllegalArgumentException("invalid index"+index);
		dr.switchTo().window(windowid.get(index));
		//log.info(index);
	}
	public void switchtoparentwindow(){
		LinkedList<String>windowid=new LinkedList<String>(getwinowhandles());
		dr.switchTo().window(windowid.get(0));
		//log.info("");
	}
	
	public void switchtoparentwithchildclose(){
		LinkedList<String>windowid=new LinkedList<String>(getwinowhandles());
		
		for(int i=1;i<windowid.size();i++){
			//log.info(windowid.get(i));
			dr.switchTo().window(windowid.get(i));
			dr.close();
			
		}switchtoparentwindow();
	}
	
	public void switchtoframe(String nameorid){
		dr.switchTo().frame(nameorid);
		
		
	}
}
