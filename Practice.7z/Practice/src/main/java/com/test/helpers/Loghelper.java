package com.test.helpers;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Loghelper {
	public static boolean root=false;
	public static Logger  getlogger(Class clas){
		if(root){
			return Logger.getLogger(clas);
		}
	//	PropertyConfigurator.configure(Resourcehelper.getResourcePath("/src/resource/log4j.properties"));
	root=true;
	return Logger.getLogger(clas);
	}

}
