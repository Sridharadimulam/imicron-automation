package com.test.helpers;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Javascripthelper {
	public WebDriver dr;

	private Logger log=Logger.getLogger(Javascripthelper.class);
	public Javascripthelper(WebDriver dr){
		this.dr=dr;	
		log.debug("Javascripthelper"+this.dr.hashCode());
	}

	public Object excutescript(String script){
		JavascriptExecutor exe=(JavascriptExecutor)dr;
		log.info(script);
		return exe.executeScript(script);		
	}

	public Object excutescript(String script,Object...args){
		JavascriptExecutor exe=(JavascriptExecutor)dr;
		log.info(script);
		return exe.executeScript(script,args);		
	}
	
	public void scrolltoelement(WebElement element){
		excutescript("window.scrollTo(arguement[0],arguement[1])",element.getLocation().x,element.getLocation().y);
		log.info(element);
	}
	public void scrolltoelementandclick(WebElement element){
		scrolltoelement(element);
		element.click();
		log.info(element);
	}
	public void scrollIntoview(WebElement element){
		excutescript("arguements[0].scrollIntoView()",element);
		
		log.info(element);
	}
	public void scrollIntoviewandclick(WebElement element){
	scrollIntoview(element);	
	element.click();
		log.info(element);
	}
	public void scrollDownvertically(){
		excutescript("window.scrollTo(0,document.body.scrollHeight)");
			
		}
	public void scrollupvertically(){
		excutescript("window.scrollTo(0,-document.body.scrollHeight)");
			
		}
	public void scrolldownByPixcel(){
		excutescript("window.scrollBy(0,1500)");	
		}
	public void scrollupByPixcel(){
		excutescript("window.scrollBy(0,-1500)");
		}
	public void zoomByPercentage(){
		excutescript("document.body.style.zoom='40%'");
		}
	public void zoomBy100Percentage(){
		excutescript("document.body.style.zoom='100%'");
		}
}
