
package com.test.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Datehelper {

	public static String getcurrentDatetime(){
		DateFormat datefarmat=new SimpleDateFormat("_yyyy_MM_dd_HH-mm-ss");
		
		Calendar cal=Calendar.getInstance();
		String time=""+datefarmat.format(cal.getTime());
		
		return time;
	}
	public static String getcurrentate(){
		return getcurrentDatetime().substring(0,11);
	}
	
	
	public static void main(String args){
		Datehelper d=new Datehelper();
		System.out.println(Datehelper.getcurrentate());
	}
}
