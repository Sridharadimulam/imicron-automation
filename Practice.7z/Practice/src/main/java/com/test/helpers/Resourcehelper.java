package com.test.helpers;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class Resourcehelper {
	
	public static String getResourcepath(String resource){
		String path=getBaseResourcepath()+resource;
		return path;
	}
	public static String getBaseResourcepath(){
		String path=System.getProperty("user.dir");
		System.out.println(path);
		return path;
		
	}
	public static  InputStream getResourcepathinputstream(String path) throws FileNotFoundException  {
		return new FileInputStream(Resourcehelper.getResourcepath(path));
		
	}
	
	
	
}
