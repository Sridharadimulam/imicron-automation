package com.test.testexamples;



public class Configreader extends Basetestdriver{

public String getusername(){
	return OR.getProperty("username");
}
public String getpassword(){
	return OR.getProperty("password");
}
public String getwebsite(){
	return OR.getProperty("Website");
}
public String getpageloadtimeout(){
	return OR.getProperty("pageloadtimeout");
}
public String getbrowser(){
	return OR.getProperty("Browser");
}
public int getimplicitwait(){
	return Integer.parseInt(OR.getProperty("implicitewait"));
}
public int getExplicitwait(){
	return Integer.parseInt(OR.getProperty("explicitwait"));
}
public String getdbtype(){
	return OR.getProperty("dbname");
}
public String getbconnectionstr(){
	return OR.getProperty("Database.connectionstr");
}



public static void main(String args[]){
	Configreader c=new Configreader();
	c.getbrowser();
	System.out.println(c.getbrowser());
}
}
