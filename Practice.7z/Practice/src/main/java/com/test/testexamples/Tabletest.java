package com.test.testexamples;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Tabletest {
	  public static void main(String[] args) {
	    	WebDriver dr;
	    	 dr= new ChromeDriver();
	    	 dr.get("http://demo.guru99.com/test/web-table-element.php");     
	    	 dr.manage().window().maximize();
	    	 
	    	 dr.findElement(By.xpath("//*[@id='leftcontainer']/table/thead/tr/th[1]")).getText();
List<WebElement>col=dr.findElements(By.xpath("//*[@id='leftcontainer']/table/thead/tr/th"));
System.out.println(col.size());
System.out.println(col.get(0).getText());
List<WebElement>row=dr.findElements(By.xpath("//*[@id='leftcontainer']/table/tbody/tr/td[1]"));
System.out.println(row.size());
WebElement basetable=dr.findElement(By.tagName("table"));
WebElement tableRow = basetable.findElement(By.xpath("//*[@id='leftcontainer']/table/tbody/tr[16]"));
System.out.println(tableRow.getText());
WebElement tablecell= basetable.findElement(By.xpath("//*[@id='leftcontainer']/table/tbody/tr[16]/td[2]"));
System.out.println(tablecell.getText());

}}
