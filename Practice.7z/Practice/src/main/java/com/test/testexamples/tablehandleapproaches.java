package com.test.testexamples;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class tablehandleapproaches {
public WebDriver dr;
	public static void main(String[] args) throws InterruptedException {
	WebDriver dr;
	dr=new ChromeDriver();
dr.get("https://uat-gms.thebigword.com/SingleSignOn/");
dr.manage().window().maximize();
dr.findElement(By.xpath("//*[@id='Username']")).sendKeys("Techwave.Client1");
dr.findElement(By.xpath("//*[@id='Password']")).sendKeys("thebigUat11");
dr.findElement(By.xpath("//*[@id='loginButton']")).click();
Thread.sleep(3000);

dr.findElement(By.xpath("//*[@id='Tile1']")).click();
Thread.sleep(2000);
//String s=dr.findElement(By.xpath("//div[@id='ProjectsGrid']/table[1]/tbody/tr")).getText();
//System.out.println(s);
WebElement htmltable=dr.findElement(By.xpath("//div[@id='ProjectsGrid']/table[1]/tbody"));

List<WebElement> rows=htmltable.findElements(By.tagName("tr"));

 

for(int rnum=0;rnum<rows.size();rnum++)

{

List<WebElement> columns=rows.get(rnum).findElements(By.tagName("td"));

System.out.println("Number of columns:"+columns.size());

for(int cnum=0;cnum<columns.size();cnum++)

{

//System.out.println(columns.get(cnum).getText());
if(columns.get(cnum).getText().equalsIgnoreCase("22292")){
	dr.findElement(By.xpath("//*[@id='ProjectsGrid']/table/tbody/tr/td[cnum]/a[1]")).click();
}
	
}

}


	}

}
