package com.test.testexamples;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class selectdateyearmonth {
public WebDriver dr;
	public void setday(String day){
		List<WebElement>days=dr.findElements(By.xpath(""));
		Iterator<WebElement>itr=days.iterator();
		while(itr.hasNext()){
			WebElement c=itr.next();
			String text=c.getText().trim().toString();
			if(text.equals(day)){
			
				System.out.println(day);
			c.click();
			break;
			}
		}}
		public void setmonth(String month){
			List<WebElement>months=dr.findElements(By.xpath(""));
			Iterator<WebElement>itr=months.iterator();
			while(itr.hasNext()){
				WebElement c=itr.next();
				String text=c.getText().trim().toString();
				if(text.equals(month)){
				System.out.println(month);
				c.click();
				break;
				}
			}}
			public void setyear(String year){
				List<WebElement>years=dr.findElements(By.xpath(""));
				Iterator<WebElement>itr=years.iterator();
				while(itr.hasNext()){
					WebElement c=itr.next();
					String text=c.getText().trim().toString();
					if(text.equals(year)){
					System.out.println(year);
					c.click();
					break;
				}
	}
}}
