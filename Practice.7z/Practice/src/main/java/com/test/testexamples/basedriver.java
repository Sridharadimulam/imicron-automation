package com.test.testexamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class basedriver {
	public static  WebDriver dr;
public void sendtext(WebDriver dr,By locatortype,String value){
	
dr.findElement(locatortype).sendKeys(value);
System.out.println("locatortype is"+locatortype);
}

public void getelementvalue(WebDriver dr,By locatortype){
dr.findElement(locatortype).getText();	
System.out.println("locatortype is"+locatortype+dr.findElement(locatortype).getText());
}

public void clickelement(WebDriver dr,By locatortype){
dr.findElement(locatortype).click();
}

public void geturl(WebDriver dr,String url){
	dr=new ChromeDriver();

	
dr.get(url);
dr.manage().window().maximize();
}
public void gettitle(WebDriver dr){
dr.getTitle();

}
public void getcurrenturl(){
String urltest=dr.getCurrentUrl();
System.out.println(urltest);
}

public void getpagesource(WebDriver dr){
dr.getPageSource();
}

}
