package com.test.testexamples;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Allelementshandle {
	public static WebDriver dr;
	@Test
	public static void te() throws InterruptedException{
		//scrollto();
		//radio();
		//checkbox();
		//nav();
		//handlealert();
		//handledrpdown();
		//draganddrop();
		
		//browsercommands();
		assertioncommands();
		//ele();
	}
	
	public static void scrollto(){
 dr=new ChromeDriver();
 dr.get("https://www.javatpoint.com/selenium-webdriver-scrolling-web-page");
 dr.manage().window().maximize();
 JavascriptExecutor js=(JavascriptExecutor)dr;
 js.executeScript("scrollBy(0,1200)");
 System.out.println("scrolling is sucess");
 dr.close();
}
	public static void radio(){
		 dr=new ChromeDriver();
		 dr.get("C:\\Users\\10555\\Desktop\\Auto source detection\\files to test\\html\\radio.html");
		 dr.manage().window().maximize();
		 dr.findElement(By.xpath("//input[@value='Banana']")).click();  
		 
		 int a = dr.findElements(By.xpath("//input [@name='group1']")).size();  
		 int b = dr.findElements(By.xpath("//input [@name='group1']")).size(); 
	        System.out.println(a);  
	        System.out.println(b); 
	        for(int i=1;i<=a;i++)  
	        {  
	            dr.findElements(By.xpath("//input[@name='group2']")).get(2).click();  
	            dr.findElements(By.xpath("//input[@name='group1']")).get(2).click();  
	        }  
		 dr.close();
	}
	
	public static void checkbox(){
		 dr=new ChromeDriver();
	   dr.navigate().to("https://www.spicejet.com/");  
	   dr.manage().window().maximize();
       System.out.println(dr.findElement(By.cssSelector("input[id*='SeniorCitizenDiscount']")).isSelected());  
       dr.findElement(By.cssSelector("input[id*='SeniorCitizenDiscount']")).click();  
       System.out.println(dr.findElement(By.cssSelector("input[id*='SeniorCitizenDiscount']")).isSelected());  
       dr.close();  
	}
	public static void nav() throws InterruptedException{
		 dr=new ChromeDriver();
		   dr.navigate().to("https://www.moltonbrown.com/");  
		   dr.manage().window().maximize();
		   dr.navigate().back();
		   System.out.println("back done" );
		   dr.navigate().forward();  
		   Thread.sleep(2000);
		   System.out.println("forward done" );
		   dr.navigate().refresh();  
		   System.out.println("refresh done" );
		   dr.close();
	}

	public static void handlealert(){
		 dr=new ChromeDriver();
		   dr.navigate().to("https://www.testandquiz.com/selenium/testing.html");   
		   dr.manage().window().maximize();
		   dr.findElement(By.linkText("Generate Alert Box")).click();  
		   Alert alert = (Alert) dr.switchTo().alert();  
		   alert.accept();   
		   dr.findElement(By.linkText("Generate Confirm Box")).click(); 
	        Alert confirmBox = (Alert) dr.switchTo().alert();  
	        dr.switchTo().alert().getText();      
	      //  ((Alert) confirmBox).dismiss();  
	       // dr.switchTo().alert().accept();  
	        alert.accept();  
	        
	        //dr.switchTo().alert().dismiss();  
	        confirmBox.dismiss();  
	        //send text
	        dr.switchTo().alert().sendKeys("Text");  
       
	}	
	public static void handledrpdown(){
		 dr=new ChromeDriver();
		   dr.navigate().to("https://www.testandquiz.com/selenium/testing.html");   
		   dr.manage().window().maximize();
		   Select dropdown = new Select(dr.findElement(By.id("testingDropdown")));  
		   dropdown.selectByVisibleText("Database Testing");   
	}
	
	
	public static void draganddrop(){
		 dr=new ChromeDriver();
		   dr.navigate().to("https://www.testandquiz.com/selenium/testing.html");   
		   dr.manage().window().maximize();
		   
		   WebElement from = dr.findElement(By.id("sourceImage"));
		   
		   WebElement to = dr.findElement(By.id("targetDiv")); 
		   Actions act = new Actions(dr);  
	        //Performing the drag and drop action  
           act.dragAndDrop(from,to).build().perform();   
		
	}
	public static void browsercommands(){
		dr=new ChromeDriver();
		   dr.navigate().to("https://www.testandquiz.com/selenium/testing.html");   
		   dr.manage().window().maximize();
		   System.out.println(dr.getCurrentUrl());
		   String PageSource = dr.getPageSource(); 
		   //System.out.println(PageSource);
		   System.out.println(dr.getTitle());
		 //  dr.quit();
		   dr.close();
	}
	public static void assertioncommands(){
		dr=new ChromeDriver();
		   dr.navigate().to("https://www.moltonbrown.com/store/index.jsp");   
		   dr.manage().window().maximize();
		   /*assertFalse
		  here it is getting assertion error  "java.lang.AssertionError: expected [false] but found [true]"
		   Assert.assertFalse(dr.findElement(By.xpath("//*[@id='atg_store_searchSubmit']")).isDisplayed());*/
		  
		   //assertTrue
		   
		   Assert.assertTrue(dr.findElement(By.xpath("//*[@id='atg_store_searchSubmit']")).isDisplayed());
		   System.out.println("assertion equal is passed");
			  
		  // AssertEquals
		 String current=  dr.getCurrentUrl();
		   System.out.println(current);
		   String act=  "https://www.moltonbrown.com/store/index.jsp";
		   System.out.println(act);
		   Assert.assertEquals(act,current);  
		   
		   System.out.println("assertEquals is passed"+"act is"+act + "current is"+current);
		  // dr.close();
		   
		/* //  AssertNotEquals
		   String current1=  dr.getCurrentUrl();
		   System.out.println(current);
		   String act1=  "https://www.moltonbrown.com/store/index.jsp";
		  // System.out.println(act1);
		   Assert.assertNotEquals(act1,current1); */ 
		   
		/*  // AssertNull
		   Assert.assertNull(null);  
		   System.out.println("Hello...This is javaTpoint");  
		   //assertNotNull
		   Assert.assertNotNull(10);  
		    System.out.println("Hello World"); */ 
}
	
	
	
	
	
	
	public static void ele() throws InterruptedException{
		dr=new ChromeDriver();
		   dr.navigate().to("https://www.moltonbrown.com/store/index.jsp");   
		   dr.manage().window().maximize();
		   
		   //click
		WebElement e=dr.findElement(By.xpath("//*[@id='atg_store_searchSubmit']"));
		e.click();
		System.out.println(e.getTagName());
		
		
		WebElement e1=dr.findElement(By.xpath("//*[@id='atg_store_searchInput']"));
		boolean status =  e1.isDisplayed();
		System.out.println(status);
		boolean status1 =  e1.isEnabled();
		System.out.println(status1);
		if(status1){
			e1.sendKeys("test");
		}
		e1.clear();
		e1.sendKeys("test");
		System.out.println("test is entered");
		Thread.sleep(2000);
		e1.clear();
		System.out.println(e.getText());
		//get dimention  and get size
	Dimension dimensions = e1.getSize();  
	System.out.println("Height :" + dimensions.height + "Width : "+ dimensions.width);  
	
	//get location
	Point point = e1.getLocation();  
	System.out.println("X cordinate : " + point.x + "Y cordinate: " + point.y);  
	//getattribute
	System.out.println(e1.getAttribute("id"));
	System.out.println("classnameis:"+e1.getClass());
	System.out.println("classnameis:"+e1.getTagName());
	
		dr.close();
		
	}

	public static  void browsertest(){
		
		/*for firefox
		System.setProperty("webdriver.gecko.driver","D:\\GeckoDriver\\geckodriver.exe" );  
        DesiredCapabilities capabilities = DesiredCapabilities.firefox();  
        capabilities.setCapability("marionette",true);  
        WebDriver driver= new FirefoxDriver(capabilities); 
    FirefoxOptions options = new FirefoxOptions();  
    options.setLegacy(true);*/
		
		/*for IE
		  System.setProperty("webdriver.ie.driver", "D:\\IE Driver Server\\IEDriverServer.exe");  
		          // Instantiate a IEDriver class.       
        WebDriver driver=new InternetExplorerDriver(); 
		 */
		
		
		/*for safari
		 WebDriver driver = new SafariDriver();   */
		//for chrome
		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe");  
		WebDriver driver=new ChromeDriver();  
	}
}