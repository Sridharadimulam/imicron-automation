package com.test.testexamples;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Pagenation {
	public static void main(String[] args) throws InterruptedException {
		WebDriver dr;
		String j="22274";
		 dr= new ChromeDriver();
		 dr.get("https://uat-gms.thebigword.com/SingleSignOn/");     
		 dr.manage().window().maximize();
		dr.findElement(By.xpath("//*[@id='Username']")).sendKeys("Techwave.Client1");
		dr.findElement(By.xpath("//*[@id='Password']")).sendKeys("thebigUat11");
		dr.findElement(By.xpath("//*[@id='loginButton']/span[2]")).click();
		Thread.sleep(3000);	
		dr.findElement(By.xpath("//*[@id='Tile1']/span[2]")).click();
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor) dr;
		js.executeScript("window.scrollBy(0,1100)");
		List<WebElement> pagination=dr.findElements(By.xpath("//*[@id='ProjectsGrid']/div/ul/li"));
		//verify the pagenation s presenet or not
		if(pagination .size()>0){ 
			System.out.println("pagination exists"); 
			//get size of the pagenation
		System.out.println(pagination.size());
		//iterate the pagenation
		for(int i2=1;i2<pagination.size();i2++){
			//click pagenation links(1,2,3,4...)
			pagination.get(i2).click();
			Thread.sleep(2000);
			//for stale element we need to initalize the pagenation
		
		pagination=dr.findElements(By.xpath("//*[@id='ProjectsGrid']/div/ul/li"));
		System.out.println(pagination.get(i2).getText()+"done");
		}
		}else { 
			System.out.println("pagination not exists"); 
		}}}
