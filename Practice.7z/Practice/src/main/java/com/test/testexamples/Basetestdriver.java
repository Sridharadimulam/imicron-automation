package com.test.testexamples;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;


public class Basetestdriver {
	private Logger log=Logger.getLogger(Basetestdriver.class);
	public WebDriver dr;
	public Properties OR;
	public FileInputStream fi;
	public File f;

	public ITestResult result;

	static{
		Calendar cal=Calendar.getInstance();
		SimpleDateFormat farmat=new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		//extent=new ExtentReports(System.getProperty("user.dir")+"\\src\\main\\java\\Reports");
	}
	public void getbrowser(String browser){
		if(System.getProperty("os.name").contains("window")){
			if(browser.equalsIgnoreCase("firefox")){
				System.out.println(System.getProperty("user.dir"));
				System.setProperty("Webdriver.gecko.driver", System.getProperty("user.dir")+"geckodriver.exe");
				dr =new FirefoxDriver();

			}
			else if(browser.equalsIgnoreCase("chrome")){
				System.out.println(System.getProperty("user.dir"));
				System.setProperty("Webdriver.gecko.driver", System.getProperty("user.dir")+"chromedriver.exe");
				dr =new ChromeDriver();
			}
		}else if(System.getProperty("os.name").contains("Mac")){
			if(browser.equalsIgnoreCase("firefox")){
				System.out.println(System.getProperty("user.dir"));
				System.setProperty("Webdriver.gecko.driver", System.getProperty("user.dir")+"geckodriver");
				dr =new FirefoxDriver();

			}
			else if(browser.equalsIgnoreCase("chrome")){
				System.out.println(System.getProperty("user.dir"));
				System.setProperty("Webdriver.gecko.driver", System.getProperty("user.dir")+"chromedriver");
				dr =new ChromeDriver();
			}
		}
	}


	public void Loadpropertiesfile() throws IOException{

		String log4jconfigpath="";
		PropertyConfigurator.configure(log4jconfigpath);
		OR=new Properties();
		f=new File(System.getProperty("user.dir")+"\\src\\main\\java\\com\\test\\config\\config.properties");
		fi=new FileInputStream(f);
		OR.load(fi);
		f=new File(System.getProperty("user.dir")+"\\config1.properties");
		fi=new FileInputStream(f);
		OR.load(fi);
	}
	public void getscrenshot(String imagename) throws IOException{
		File image=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		String imagelocation=System.getProperty("user.dir")+"\\src\\main\\java\\screenshots\\";
		Calendar cal=Calendar.getInstance();
		SimpleDateFormat farmater=new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		String actimagename=imagelocation+imagename+"_"+farmater.format(cal.getTime())+".png";
		File  Destfile=new File(actimagename);
		FileUtils.copyFile(image, Destfile);

	}


	public WebElement waitforelement(WebDriver dr,long time,WebElement element){
		WebDriverWait wait=new WebDriverWait(dr, time);
		return wait.until(ExpectedConditions.elementToBeClickable(element));

	}


	public WebElement waitforelementwithpollinginterval(WebDriver dr,long time,WebElement element){
		WebDriverWait wait=new WebDriverWait(dr, time);
		wait.pollingEvery(5,TimeUnit.SECONDS);
		wait.ignoring(NoSuchElementException.class);
		return wait.until(ExpectedConditions.elementToBeClickable(element));

	}


	public void implicitwait(long time){
		dr.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
	}

	public WebElement getlocator(String locator) throws Exception{
		String []split=locator.split(":");
		String locatortype=split[0];
		String locatorvalue=split[1];
		if(locatortype.toLowerCase().equals("id")){
			return dr.findElement(By.id(locatorvalue));
		}else if(locatortype.toLowerCase().equals("xpath")){
			return dr.findElement(By.xpath(locatorvalue));

		}else if(locatortype.toLowerCase().equals("name")){
			return dr.findElement(By.name(locatorvalue));
		}
		else if(locatortype.toLowerCase().equals("classname")){
			return dr.findElement(By.className(locatorvalue));
		}else if(locatortype.toLowerCase().equals("tag")){
			return dr.findElement(By.tagName(locatorvalue));
		}else if(locatortype.toLowerCase().equals("linktext")){
			return dr.findElement(By.linkText(locatorvalue));
		}else if(locatortype.toLowerCase().equals("partiallinktext")){
			return dr.findElement(By.partialLinkText(locatorvalue));
		}

		else if(locatortype.toLowerCase().equals("cssselector")){
			return dr.findElement(By.cssSelector(locatorvalue));
		}

		else
			throw  new Exception("unknown locator type"+locatortype+"'");
	}


	public List<WebElement> getlocators(String locator) throws Exception{
		String []split=locator.split(":");
		String locatortype=split[0];
		String locatorvalue=split[1];
		if(locatortype.toLowerCase().equals("id")){
			return dr.findElements(By.id(locatorvalue));
		}else if(locatortype.toLowerCase().equals("xpath")){
			return dr.findElements(By.xpath(locatorvalue));

		}else if(locatortype.toLowerCase().equals("name")){
			return dr.findElements(By.name(locatorvalue));
		}
		else if(locatortype.toLowerCase().equals("classname")){
			return dr.findElements(By.className(locatorvalue));
		}else if(locatortype.toLowerCase().equals("tag")){
			return dr.findElements(By.tagName(locatorvalue));
		}else if(locatortype.toLowerCase().equals("linktext")){
			return dr.findElements(By.linkText(locatorvalue));
		}else if(locatortype.toLowerCase().equals("partiallinktext")){
			return dr.findElements(By.partialLinkText(locatorvalue));
		}

		else if(locatortype.toLowerCase().equals("cssselector")){
			return dr.findElements(By.cssSelector(locatorvalue));
		}

		else
			throw  new Exception("unknown locator type"+locatortype+"'");
	}
	public WebElement getwebelement(String locator) throws Exception{
		return getlocator(OR.getProperty(locator));


	}
	public List<WebElement> getwebelements(String locator) throws Exception{
		return getlocators(OR.getProperty(locator));


	}
	public static void main(String args[]){
		Basetestdriver b=new Basetestdriver();
		b.getbrowser("window");


	}
}
