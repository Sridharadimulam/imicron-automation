package com.test.testexamples;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Filterclass {
public static WebDriver dr;
	@Test
public static void test() throws InterruptedException{
		dr=new ChromeDriver();
		
	dr.get("https://www.sonnysdirect.com/sonnysdirect/en/Parts-Supplies/Air-Supply/c/Air-Supply");
	
	dr.manage().window().maximize();
	WebElement web=dr.findElement(By.xpath("//*[@id='sortOptions1']"));
	Select s=new Select(web);
	s.selectByIndex(5);
	
	Thread.sleep(3000);
	
//	List<WebElement> price = dr.findElements(By.xpath("/html/body/main/div[4]/div[2]/div/div[1]/div[1]/div/div[2]/ul/div[1]/div/li[1]/div[1]/div[3]"));
	List<WebElement> price = dr.findElements(By.xpath("//span[@class='prices']"));
	
	ArrayList<Integer>array=new ArrayList<Integer>();
	Iterator< WebElement>itr=price.iterator();
while(itr.hasNext()){
	String p=itr.next().getText();
	if(p.contains("")){
		String actdata=p.substring(1);
		System.out.println(actdata);
		double p1=Double.parseDouble(actdata);
		int productprice=(int)(p1);
		
	}
}
	}
	

}
