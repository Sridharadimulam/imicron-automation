package test;

import org.openqa.selenium.WebDriver;

import com.test.testexamples.Basetestdriver;

public class Homepage extends Basetestdriver {

public Homepage(WebDriver dr){

	this.dr=dr;
}
	

}
